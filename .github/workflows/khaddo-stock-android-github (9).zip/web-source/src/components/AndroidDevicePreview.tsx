import React, { useMemo, useState } from 'react';
import {
  ArrowUpRight,
  BatteryCharging,
  Camera,
  CheckCircle2,
  FileDown,
  ImagePlus,
  RefreshCw,
  ShieldCheck,
  Signal,
  Smartphone,
  Wifi,
} from 'lucide-react';
import type { AndroidAppConfig } from '../shared/androidConfig';

export interface BridgeEvent {
  id: string;
  time: string;
  hook: string;
  detail: string;
  enabled: boolean;
}

interface AndroidDevicePreviewProps {
  config: AndroidAppConfig;
  events: BridgeEvent[];
  onTriggerEvent: (hook: string, detail: string, enabled: boolean) => void;
  onClearEvents: () => void;
}

type PreviewTab = 'app' | 'launcher' | 'logs';

export const AndroidDevicePreview: React.FC<AndroidDevicePreviewProps> = ({
  config,
  events,
  onTriggerEvent,
  onClearEvents,
}) => {
  const [previewTab, setPreviewTab] = useState<PreviewTab>('app');
  const [activeFeedback, setActiveFeedback] = useState<string | null>(null);

  const parsedChallanNo = useMemo(() => {
    try {
      const u = new URL(config.targetUrl);
      return u.searchParams.get('challanNo') || '2627-0027897806';
    } catch {
      return '2627-0027897806';
    }
  }, [config.targetUrl]);

  const handleSimulatedAction = (
    hook: string,
    detail: string,
    enabled: boolean,
    feedbackMsg: string
  ) => {
    onTriggerEvent(hook, detail, enabled);
    setActiveFeedback(feedbackMsg);
    window.setTimeout(() => {
      setActiveFeedback((prev) => (prev === feedbackMsg ? null : prev));
    }, 2600);
  };

  return (
    <div className="flex flex-col items-center">
      {/* Preview Mode Switcher */}
      <div className="w-full max-w-[380px] flex items-center justify-between gap-2 mb-4">
        <div
          className="inline-flex items-center gap-1 p-1 bg-slate-100 rounded-lg border border-slate-200 w-full"
          role="tablist"
          aria-label="Android preview views"
        >
          <button
            type="button"
            role="tab"
            aria-selected={previewTab === 'app'}
            onClick={() => setPreviewTab('app')}
            className={`flex-1 px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              previewTab === 'app'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            App Screen
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={previewTab === 'launcher'}
            onClick={() => setPreviewTab('launcher')}
            className={`flex-1 px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              previewTab === 'launcher'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Icon & Splash
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={previewTab === 'logs'}
            onClick={() => setPreviewTab('logs')}
            className={`flex-1 px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              previewTab === 'logs'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Bridge ({events.length})
          </button>
        </div>
      </div>

      {/* Android Device Bezel */}
      <div className="w-full max-w-[368px] rounded-[38px] bg-slate-900 p-3 shadow-xl border border-slate-800">
        <div className="overflow-hidden rounded-[28px] bg-slate-50 border border-slate-800/40 flex flex-col h-[660px]">
          {/* Android Status Bar */}
          <div
            className="px-5 py-2 flex items-center justify-between text-white text-[11px] font-medium select-none shrink-0"
            style={{ backgroundColor: config.primaryColor }}
          >
            <span className="tabular-nums font-semibold">9:41</span>
            <div className="w-16 h-3.5 rounded-full bg-slate-950/35" aria-hidden="true" />
            <div className="flex items-center gap-1.5">
              <Signal className="h-3 w-3" />
              <Wifi className="h-3 w-3" />
              <BatteryCharging className="h-3.5 w-3.5" />
            </div>
          </div>

          {/* Screen Body */}
          {previewTab === 'app' && (
            <div className="flex-1 overflow-y-auto bg-[#f1f5fb] flex flex-col justify-between">
              <div className="p-3 space-y-3" style={{ fontFamily: 'var(--font-bengali)' }}>
                {/* Hero Header matching Apps Script UI */}
                <div
                  className="rounded-2xl px-4 py-3.5 text-white shadow-sm flex items-center justify-between gap-2"
                  style={{
                    background: `linear-gradient(120deg, ${config.primaryColor}, ${config.secondaryColor} 55%, #6d4fd6 100%)`,
                  }}
                >
                  <div className="min-w-0">
                    <h3 className="text-[15px] font-bold leading-snug truncate">
                      {config.appName || 'চালান স্ক্যান ও ব্যবস্থাপনা'}
                    </h3>
                    <p className="text-[11px] text-white/85 truncate font-sans">
                      {config.packageName}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      handleSimulatedAction(
                        'SwipeRefreshLayout.onRefresh',
                        `Reloaded ${config.targetUrl.slice(0, 48)}...`,
                        config.enablePullToRefresh,
                        config.enablePullToRefresh
                          ? 'WebView pull-to-refresh triggered'
                          : 'Pull-to-refresh is disabled in config'
                      )
                    }
                    className="h-9 w-9 rounded-xl bg-white/15 hover:bg-white/25 flex items-center justify-center shrink-0 transition-colors cursor-pointer"
                    title="Test SwipeRefreshLayout reload"
                    aria-label="Test reload"
                  >
                    <RefreshCw className="h-4 w-4 text-white" />
                  </button>
                </div>

                {/* Live Toast Feedback */}
                {activeFeedback && (
                  <div className="rounded-xl bg-slate-900 text-white px-3 py-2 text-[11px] font-sans flex items-center gap-2 shadow-sm">
                    <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400 shrink-0" />
                    <span className="truncate">{activeFeedback}</span>
                  </div>
                )}

                {/* Step 1: QR Scan */}
                <div className="rounded-2xl bg-white p-3.5 border border-slate-200/80 shadow-xs">
                  <h4 className="text-xs font-bold text-slate-900 mb-2.5">ধাপ ১: QR স্ক্যান</h4>
                  <div className="grid grid-cols-2 gap-2.5">
                    <div className="rounded-xl bg-[#e3f6f1] p-2.5">
                      <div className="text-[11px] font-bold text-[#0b7a8f] mb-1.5">মূল চালান</div>
                      <button
                        type="button"
                        onClick={() =>
                          handleSimulatedAction(
                            'WebChromeClient.onPermissionRequest',
                            'Requested CAMERA for html5-qrcode (মূল চালান)',
                            config.enableCameraQr,
                            config.enableCameraQr
                              ? 'Camera permission granted to WebView'
                              : 'Camera permission disabled in APK config'
                          )
                        }
                        className="w-full py-2 px-2 rounded-lg text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                        style={{
                          background: `linear-gradient(135deg, ${config.primaryColor}, ${config.secondaryColor})`,
                        }}
                      >
                        <Camera className="h-3.5 w-3.5 shrink-0" />
                        <span>স্ক্যান</span>
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          handleSimulatedAction(
                            'WebChromeClient.onShowFileChooser',
                            'Opened Camera + Gallery chooser (image/*)',
                            config.enableFileUpload,
                            config.enableFileUpload
                              ? 'Android FileProvider camera/gallery chooser opened'
                              : 'File chooser disabled in APK config'
                          )
                        }
                        className="mt-1.5 w-full py-1.5 px-2 rounded-lg bg-white text-slate-800 border border-slate-200 text-[11px] font-semibold flex items-center justify-center gap-1 cursor-pointer hover:bg-slate-50"
                      >
                        <ImagePlus className="h-3 w-3 shrink-0" />
                        <span>ছবি তুলে</span>
                      </button>
                    </div>

                    <div className="rounded-xl bg-[#fff3df] p-2.5">
                      <div className="text-[11px] font-bold text-[#b8470b] mb-1.5">আয়কর চালান</div>
                      <button
                        type="button"
                        onClick={() =>
                          handleSimulatedAction(
                            'WebChromeClient.onPermissionRequest',
                            'Requested CAMERA for html5-qrcode (আয়কর চালান)',
                            config.enableCameraQr,
                            config.enableCameraQr
                              ? 'Camera permission granted to WebView'
                              : 'Camera permission disabled in APK config'
                          )
                        }
                        className="w-full py-2 px-2 rounded-lg text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                        style={{
                          background: 'linear-gradient(135deg, #f59e0b, #e8590c)',
                        }}
                      >
                        <Camera className="h-3.5 w-3.5 shrink-0" />
                        <span>স্ক্যান</span>
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          handleSimulatedAction(
                            'WebChromeClient.onShowFileChooser',
                            'Opened Camera + Gallery chooser (image/*)',
                            config.enableFileUpload,
                            config.enableFileUpload
                              ? 'Android FileProvider camera/gallery chooser opened'
                              : 'File chooser disabled in APK config'
                          )
                        }
                        className="mt-1.5 w-full py-1.5 px-2 rounded-lg bg-white text-slate-800 border border-slate-200 text-[11px] font-semibold flex items-center justify-center gap-1 cursor-pointer hover:bg-slate-50"
                      >
                        <ImagePlus className="h-3 w-3 shrink-0" />
                        <span>ছবি তুলে</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Step 2: Challan Info */}
                <div className="rounded-2xl bg-white p-3.5 border border-slate-200/80 shadow-xs space-y-2.5">
                  <h4 className="text-xs font-bold text-slate-900">ধাপ ২: চালানের তথ্য</h4>
                  <div>
                    <div className="text-[11px] font-semibold text-slate-500 mb-1">
                      চালান নম্বর (URL parameter)
                    </div>
                    <div className="flex items-center justify-between gap-2 rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-2">
                      <span className="font-mono text-xs font-semibold text-slate-900 tabular-nums truncate">
                        {parsedChallanNo}
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                          handleSimulatedAction(
                            'WebViewClient.shouldOverrideUrlLoading',
                            'External verification link routed via Chrome / Browser',
                            config.openExternalVerifyInBrowser,
                            config.openExternalVerifyInBrowser
                              ? 'Verification link routed to Android browser'
                              : 'Verification link kept inside WebView'
                          )
                        }
                        className="text-[11px] font-semibold text-emerald-700 hover:underline whitespace-nowrap shrink-0 cursor-pointer"
                      >
                        যাচাই ↗
                      </button>
                    </div>
                  </div>
                </div>

                {/* Step 3: Report & PDF */}
                <div className="rounded-2xl bg-white p-3.5 border border-slate-200/80 shadow-xs">
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <h4 className="text-xs font-bold text-slate-900">চালান রিপোর্ট ও PDF</h4>
                    <span className="text-[11px] text-slate-500 font-sans">html2pdf.js</span>
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      handleSimulatedAction(
                        'AndroidBlobBridge.saveBase64File',
                        'Intercepted html2pdf.js blob -> Downloads/challan-report.pdf',
                        config.enablePdfDownloads,
                        config.enablePdfDownloads
                          ? 'Saved PDF to Android Downloads folder'
                          : 'PDF Blob Bridge is disabled in APK config'
                      )
                    }
                    className="w-full py-2.5 px-3 rounded-xl text-white text-xs font-bold flex items-center justify-center gap-2 cursor-pointer"
                    style={{
                      background: 'linear-gradient(135deg, #f59e0b, #e8590c)',
                    }}
                  >
                    <FileDown className="h-4 w-4 shrink-0" />
                    <span>PDF ডাউনলোড পরীক্ষা করুন</span>
                  </button>
                </div>
              </div>

              {/* Direct Live Launch Bar */}
              <div className="p-3 bg-white border-t border-slate-200 shrink-0">
                <a
                  href={config.targetUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <span>Open Live Apps Script Web App</span>
                  <ArrowUpRight className="h-3.5 w-3.5" />
                </a>
                <p className="mt-1.5 text-[10px] leading-tight text-slate-500 text-center">
                  Google Apps Script sets X-Frame-Options: SAMEORIGIN, so it runs directly inside
                  Android WebView rather than a web iframe.
                </p>
              </div>
            </div>
          )}

          {previewTab === 'launcher' && (
            <div className="flex-1 bg-slate-900 text-white p-5 flex flex-col justify-between">
              <div>
                <div className="text-xs font-semibold text-slate-400">
                  Android Adaptive Launcher Icon
                </div>
                <div className="mt-4 flex items-center justify-center gap-5 py-6 rounded-2xl bg-slate-800/70 border border-slate-700/70">
                  {/* Squircle Icon */}
                  <div className="flex flex-col items-center gap-2">
                    <div
                      className="h-16 w-16 rounded-2xl flex items-center justify-center shadow-lg"
                      style={{
                        background: `linear-gradient(135deg, ${config.primaryColor}, ${config.secondaryColor})`,
                      }}
                    >
                      <svg viewBox="0 0 64 64" className="h-10 w-10">
                        <path
                          d="M18 12C18 10.34 19.34 9 21 9H43C44.66 9 46 10.34 46 12V53L42 50L38 53L34 50L30 53L26 50L22 53L18 50V12Z"
                          fill="#FFFFFF"
                        />
                        <rect
                          x="22"
                          y="16"
                          width="8"
                          height="8"
                          rx="1.5"
                          fill={config.primaryColor}
                        />
                        <rect
                          x="34"
                          y="16"
                          width="8"
                          height="8"
                          rx="1.5"
                          fill={config.secondaryColor}
                        />
                        <rect x="22" y="29" width="20" height="3" rx="1.5" fill="#1E293B" />
                        <rect x="22" y="35" width="14" height="2.5" rx="1.25" fill="#64748B" />
                        <rect x="22" y="40" width="17" height="2.5" rx="1.25" fill="#94A3B8" />
                      </svg>
                    </div>
                    <span className="text-[11px] text-slate-300 truncate max-w-[84px]">
                      {config.shortName || 'ChallanApp'}
                    </span>
                  </div>

                  {/* Circle Icon */}
                  <div className="flex flex-col items-center gap-2">
                    <div
                      className="h-16 w-16 rounded-full flex items-center justify-center shadow-lg"
                      style={{
                        background: `linear-gradient(135deg, ${config.primaryColor}, ${config.secondaryColor})`,
                      }}
                    >
                      <svg viewBox="0 0 64 64" className="h-9 w-9">
                        <path
                          d="M18 12C18 10.34 19.34 9 21 9H43C44.66 9 46 10.34 46 12V53L42 50L38 53L34 50L30 53L26 50L22 53L18 50V12Z"
                          fill="#FFFFFF"
                        />
                        <rect
                          x="22"
                          y="16"
                          width="8"
                          height="8"
                          rx="1.5"
                          fill={config.primaryColor}
                        />
                        <rect
                          x="34"
                          y="16"
                          width="8"
                          height="8"
                          rx="1.5"
                          fill={config.secondaryColor}
                        />
                        <rect x="22" y="29" width="20" height="3" rx="1.5" fill="#1E293B" />
                        <rect x="22" y="35" width="14" height="2.5" rx="1.25" fill="#64748B" />
                      </svg>
                    </div>
                    <span className="text-[11px] text-slate-300">Round</span>
                  </div>
                </div>
              </div>

              {/* Package Metadata Summary */}
              <div className="rounded-2xl bg-slate-800/80 border border-slate-700/70 p-4 space-y-2.5 text-xs">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-slate-400">Package ID</span>
                  <span className="font-mono text-slate-100 truncate">{config.packageName}</span>
                </div>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-slate-400">Version</span>
                  <span className="font-mono tabular-nums text-slate-100">
                    {config.versionName} ({config.versionCode})
                  </span>
                </div>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-slate-400">Target SDK</span>
                  <span className="font-mono tabular-nums text-slate-100">Android 15 (API 35)</span>
                </div>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-slate-400">Orientation</span>
                  <span className="font-mono text-slate-100 capitalize">{config.orientation}</span>
                </div>
              </div>

              <div className="flex items-center gap-2 text-[11px] text-slate-400">
                <ShieldCheck className="h-4 w-4 text-emerald-400 shrink-0" />
                <span>
                  Includes mdpi through xxxhdpi PNGs + Android 8+ adaptive vector foreground.
                </span>
              </div>
            </div>
          )}

          {previewTab === 'logs' && (
            <div className="flex-1 bg-slate-950 text-slate-100 p-4 flex flex-col">
              <div className="flex items-center justify-between gap-2 pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2 text-xs font-semibold text-slate-200">
                  <Smartphone className="h-3.5 w-3.5 text-emerald-400" />
                  <span>WebView Native Bridge</span>
                </div>
                {events.length > 0 && (
                  <button
                    type="button"
                    onClick={onClearEvents}
                    className="text-[11px] font-medium text-slate-400 hover:text-white cursor-pointer"
                  >
                    Clear
                  </button>
                )}
              </div>

              <div className="flex-1 overflow-y-auto py-3 space-y-2.5">
                {events.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center px-4 text-slate-400 text-xs">
                    <p>No bridge events recorded yet.</p>
                    <p className="mt-1 text-slate-500">
                      Tap QR Scan, Photo Upload, Verify, or PDF Download in App Screen to inspect
                      how MainActivity.kt handles them.
                    </p>
                  </div>
                ) : (
                  events.map((ev) => (
                    <div
                      key={ev.id}
                      className="rounded-xl border border-slate-800 bg-slate-900/90 p-2.5 text-[11px]"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-mono font-semibold text-emerald-400 truncate">
                          {ev.hook}
                        </span>
                        <span className="font-mono text-[10px] text-slate-500 tabular-nums shrink-0">
                          {ev.time}
                        </span>
                      </div>
                      <p className="mt-1 text-slate-300 leading-snug">{ev.detail}</p>
                      <div className="mt-1 text-[10px] font-medium text-slate-400">
                        {ev.enabled ? 'Enabled in APK build' : 'Blocked — disabled in config'}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* Android Navigation Gesture Pill */}
          <div className="bg-white border-t border-slate-200 py-2 flex justify-center shrink-0">
            <div className="w-24 h-1 rounded-full bg-slate-300" aria-hidden="true" />
          </div>
        </div>
      </div>
    </div>
  );
};
