import React, { useMemo, useState } from 'react';
import { AlertTriangle, Minus, Plus, Search, Warehouse } from 'lucide-react';
import {
  PRODUCTS,
  PRODUCT_MAP,
  type KhamalStockItem,
  type ProductCategory,
} from '../types/grain';
import { ProductIcon, formatBags, formatMetricTons } from './GrainIcons';

interface StockInventoryViewProps {
  khamalStocks: KhamalStockItem[];
  godownList: string[];
  onQuickEntry: (
    mode: 'receipt' | 'distribution' | 'shortage',
    product: ProductCategory,
    godownNo: string,
    khamalNo: string
  ) => void;
}

export const StockInventoryView: React.FC<StockInventoryViewProps> = ({
  khamalStocks,
  godownList,
  onQuickEntry,
}) => {
  const [productFilter, setProductFilter] = useState<'all' | ProductCategory>('all');
  const [godownFilter, setGodownFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [hideZeroStock, setHideZeroStock] = useState<boolean>(false);

  const filtered = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return khamalStocks.filter((k) => {
      if (productFilter !== 'all' && k.product !== productFilter) return false;
      if (godownFilter !== 'all' && k.godownNo !== godownFilter) return false;
      if (hideZeroStock && k.currentBags <= 0 && k.currentMt <= 0) return false;
      if (q) {
        const hay = `${k.godownNo} ${k.khamalNo} ${k.channels.join(' ')}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [khamalStocks, productFilter, godownFilter, hideZeroStock, searchQuery]);

  const totals = useMemo(() => {
    let bags = 0;
    let mt = 0;
    filtered.forEach((k) => {
      bags += k.currentBags;
      mt += k.currentMt;
    });
    return { bags, mt };
  }, [filtered]);

  return (
    <div className="space-y-5">
      <section className="rounded-2xl border border-slate-200 bg-white p-4 sm:p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-bold text-slate-900">গুদাম ও খামালভিত্তিক বর্তমান মজুদ</h2>
            <p className="text-xs text-slate-500 mt-0.5 tabular-nums">
              প্রদর্শিত: {filtered.length}টি খামাল · মোট {formatMetricTons(totals.mt)} মে.টন ·{' '}
              {formatBags(totals.bags)} বস্তা
            </p>
          </div>

          <label className="inline-flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={hideZeroStock}
              onChange={(e) => setHideZeroStock(e.target.checked)}
              className="h-4 w-4 rounded border-slate-300 accent-emerald-700"
            />
            <span>শূন্য মজুদ লুকান</span>
          </label>
        </div>

        <div className="flex flex-wrap items-center gap-1.5 p-1 rounded-xl bg-slate-100 border border-slate-200">
          <button
            type="button"
            onClick={() => setProductFilter('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer ${
              productFilter === 'all'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            সব পণ্য
          </button>
          {PRODUCTS.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => setProductFilter(p.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer ${
                productFilter === p.id
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ProductIcon product={p.id} className={`h-3.5 w-3.5 ${p.textColorClass}`} />
              <span>{p.shortBn}</span>
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="relative">
            <Search className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="খামাল নং, গুদাম বা চ্যানেল খুঁজুন..."
              className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-slate-50/50 pl-9 pr-3 py-2 text-sm text-slate-900 focus:bg-white focus:border-emerald-700 focus:outline-none"
            />
          </div>

          <select
            aria-label="গুদাম ফিল্টার"
            value={godownFilter}
            onChange={(e) => setGodownFilter(e.target.value)}
            className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm font-medium text-slate-800 focus:border-emerald-700 focus:outline-none"
          >
            <option value="all">সকল গুদাম</option>
            {godownList.map((g) => (
              <option key={g} value={g}>
                {g}
              </option>
            ))}
          </select>
        </div>
      </section>

      {filtered.length === 0 ? (
        <div className="rounded-2xl border border-slate-200 bg-white p-10 text-center">
          <Warehouse className="h-8 w-8 text-slate-300 mx-auto" />
          <p className="mt-3 text-sm font-semibold text-slate-700">কোনো খামাল মজুদ পাওয়া যায়নি</p>
          <p className="mt-1 text-xs text-slate-500">
            ফিল্টার পরিবর্তন করুন অথবা নতুন প্রাপ্তি যুক্ত করুন।
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {filtered.map((item) => {
            const meta = PRODUCT_MAP[item.product];
            const isEmpty = item.currentBags <= 0 && item.currentMt <= 0;
            return (
              <div
                key={item.key}
                className="rounded-2xl border border-slate-200 bg-white p-4 flex flex-col justify-between gap-3.5"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3 min-w-0">
                    <div
                      className={`h-11 w-11 rounded-xl ${meta.softBgClass} ${meta.textColorClass} flex items-center justify-center shrink-0`}
                    >
                      <ProductIcon product={item.product} className="h-6 w-6" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 text-sm font-bold text-slate-900">
                        <span className="truncate">{item.godownNo}</span>
                        <span aria-hidden="true" className="text-slate-400">
                          /
                        </span>
                        <span className="truncate">{item.khamalNo}</span>
                      </div>
                      <div className="mt-0.5 text-xs text-slate-500 truncate">
                        <span>{meta.nameBn}</span>
                        {item.channels.length > 0 && (
                          <>
                            <span aria-hidden="true"> · </span>
                            <span>{item.channels.join(', ')}</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0 tabular-nums">
                    {meta.tracksWeight ? (
                      <>
                        <div
                          className={`text-base font-extrabold ${
                            isEmpty ? 'text-slate-400' : 'text-emerald-900'
                          }`}
                        >
                          {formatMetricTons(item.currentMt)} মে.টন
                        </div>
                        <div className="text-xs font-semibold text-slate-500">
                          {formatBags(item.currentBags)} বস্তা
                        </div>
                      </>
                    ) : (
                      <div
                        className={`text-base font-extrabold ${
                          isEmpty ? 'text-slate-400' : 'text-slate-900'
                        }`}
                      >
                        {formatBags(item.currentBags)} বস্তা
                      </div>
                    )}
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                  <div className="text-[11px] text-slate-500 tabular-nums">
                    {meta.tracksWeight ? (
                      <>
                        <span>প্রাপ্তি: {formatMetricTons(item.receiptMt)} মে.টন</span>
                        <span aria-hidden="true"> · </span>
                        <span>বিতরণ: {formatMetricTons(item.distMt)} মে.টন</span>
                      </>
                    ) : (
                      <>
                        <span>প্রাপ্তি: {formatBags(item.receiptBags)} বস্তা</span>
                        <span aria-hidden="true"> · </span>
                        <span>বিতরণ: {formatBags(item.distBags)} বস্তা</span>
                      </>
                    )}
                    {(item.shortageMt > 0 || item.shortageBags > 0) && (
                      <>
                        <span aria-hidden="true"> · </span>
                        <span className="text-amber-700 font-semibold">
                          শর্টেজ:{' '}
                          {meta.tracksWeight
                            ? `${formatMetricTons(item.shortageMt)} মে.টন`
                            : `${formatBags(item.shortageBags)} বস্তা`}
                        </span>
                      </>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() =>
                        onQuickEntry('receipt', item.product, item.godownNo, item.khamalNo)
                      }
                      className="min-h-[36px] px-2.5 py-1 rounded-lg border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 text-xs font-bold text-emerald-800 flex items-center gap-1 whitespace-nowrap cursor-pointer"
                    >
                      <Plus className="h-3.5 w-3.5" />
                      <span>প্রাপ্তি</span>
                    </button>
                    {!meta.isBagProduct && (
                      <button
                        type="button"
                        disabled={
                          item.receiptBags <= 0 &&
                          item.receiptMt <= 0 &&
                          item.distBags <= 0 &&
                          item.distMt <= 0
                        }
                        onClick={() =>
                          onQuickEntry('shortage', item.product, item.godownNo, item.khamalNo)
                        }
                        className="min-h-[36px] px-2.5 py-1 rounded-lg border border-amber-200 bg-amber-50 hover:bg-amber-100 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-bold text-amber-800 flex items-center gap-1 whitespace-nowrap cursor-pointer"
                      >
                        <AlertTriangle className="h-3.5 w-3.5" />
                        <span>ঘাটতি</span>
                      </button>
                    )}
                    <button
                      type="button"
                      disabled={isEmpty}
                      onClick={() =>
                        onQuickEntry('distribution', item.product, item.godownNo, item.khamalNo)
                      }
                      className="min-h-[36px] px-2.5 py-1 rounded-lg border border-rose-200 bg-rose-50 hover:bg-rose-100 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-bold text-rose-800 flex items-center gap-1 whitespace-nowrap cursor-pointer"
                    >
                      <Minus className="h-3.5 w-3.5" />
                      <span>বিতরণ</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
