import React from 'react';
import { ArrowUpRight, Download, FolderGit2, Laptop, Smartphone } from 'lucide-react';
import type { AndroidAppConfig } from '../shared/androidConfig';

interface BuildGuidePanelProps {
  config: AndroidAppConfig;
  isDownloading: boolean;
  onDownloadProject: () => void;
}

export const BuildGuidePanel: React.FC<BuildGuidePanelProps> = ({
  config,
  isDownloading,
  onDownloadProject,
}) => {
  return (
    <div className="space-y-6">
      <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-4 text-sm text-slate-700 leading-relaxed">
        <p className="font-semibold text-slate-900">How the binary .apk is compiled</p>
        <p className="mt-1 text-slate-600">
          Compiling a signed <code className="font-mono text-xs text-slate-900">.apk</code> requires
          the Android SDK and Gradle toolchain, which cannot run inside a web browser. This studio
          packages the entire ready-to-compile Kotlin Android Studio project and a preconfigured
          GitHub Actions cloud compiler so you can produce the installable{' '}
          <code className="font-mono text-xs text-slate-900">app-debug.apk</code> in under two
          minutes.
        </p>
      </div>

      {/* Track 1: Cloud APK via GitHub Actions */}
      <div className="rounded-xl border border-slate-200 bg-white p-5">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="h-9 w-9 rounded-lg bg-emerald-50 border border-emerald-200 flex items-center justify-center shrink-0">
              <FolderGit2 className="h-4.5 w-4.5 text-emerald-700" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                01. Cloud APK Build via GitHub Actions (No Android Studio Required)
              </h3>
              <p className="mt-0.5 text-xs text-slate-500">
                Recommended if you want a downloadable .apk directly from your browser
              </p>
            </div>
          </div>
        </div>

        <ol className="mt-4 space-y-2.5 text-sm text-slate-700 list-decimal list-inside">
          <li>
            Click <strong className="text-slate-900">Download APK Project</strong> to save the
            complete <code className="font-mono text-xs">.zip</code> package.
          </li>
          <li>
            Upload the downloaded <code className="font-mono text-xs">.zip</code> file directly to a
            new GitHub repository (no need to unzip folders on your phone).
          </li>
          <li>
            Tap the repository&apos;s <strong className="text-slate-900">Actions</strong> tab,
            select <strong className="text-slate-900">set up a workflow yourself</strong>, paste{' '}
            <code className="font-mono text-xs">build-apk.yml</code> from the{' '}
            <strong className="text-slate-900">Kotlin Source</strong> tab, commit, and download{' '}
            <code className="font-mono text-xs">app-debug.apk</code> from Artifacts once finished.
          </li>
        </ol>

        <div className="mt-4 pt-4 border-t border-slate-100 flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={onDownloadProject}
            disabled={isDownloading}
            className="inline-flex items-center gap-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 px-4 py-2 text-xs font-semibold text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Download className="h-3.5 w-3.5" />
            <span>{isDownloading ? 'Packaging ZIP...' : 'Download APK Project (.zip)'}</span>
          </button>
        </div>
      </div>

      {/* Track 2: Local Android Studio */}
      <div className="rounded-xl border border-slate-200 bg-white p-5">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-lg bg-slate-100 border border-slate-200 flex items-center justify-center shrink-0">
            <Laptop className="h-4.5 w-4.5 text-slate-700" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              02. Local Build with Android Studio
            </h3>
            <p className="mt-0.5 text-xs text-slate-500">
              Best for customizing signing keys or publishing to Google Play Store
            </p>
          </div>
        </div>

        <ol className="mt-4 space-y-2 text-sm text-slate-700 list-decimal list-inside">
          <li>Extract the downloaded ZIP and open the folder in Android Studio.</li>
          <li>Wait for Gradle sync to download AndroidX WebKit &amp; Material dependencies.</li>
          <li>
            Select <strong className="text-slate-900">Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</strong>,
            then transfer <code className="font-mono text-xs">app/build/outputs/apk/debug/app-debug.apk</code> to your phone.
          </li>
        </ol>
      </div>

      {/* Track 3: Instant Android Home Screen Launch */}
      <div className="rounded-xl border border-slate-200 bg-white p-5">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-lg bg-slate-100 border border-slate-200 flex items-center justify-center shrink-0">
            <Smartphone className="h-4.5 w-4.5 text-slate-700" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              03. Instant Android Shortcut (Zero Build)
            </h3>
            <p className="mt-0.5 text-xs text-slate-500">
              Launch on Android Chrome right now without compiling an APK
            </p>
          </div>
        </div>

        <p className="mt-3 text-sm text-slate-600">
          Open your Apps Script link in Chrome on Android and choose{' '}
          <strong className="text-slate-900">Menu &gt; Add to Home screen</strong>. Note that the
          compiled APK project above provides deeper native integration, including automatic
          Downloads folder saving for <code className="font-mono text-xs">html2pdf.js</code> and
          native camera file capture.
        </p>

        <div className="mt-4">
          <a
            href={config.targetUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 px-3.5 py-2 text-xs font-semibold text-slate-800 transition-colors whitespace-nowrap shrink-0"
          >
            <span>Open Apps Script App</span>
            <ArrowUpRight className="h-3.5 w-3.5" />
          </a>
        </div>
      </div>
    </div>
  );
};
