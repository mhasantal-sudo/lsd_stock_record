import React from 'react';
import type { ProductCategory } from '../types/grain';

interface ProductIconProps {
  product: ProductCategory | 'bosta';
  className?: string;
}

export const ProductIcon: React.FC<ProductIconProps> = ({ product, className = 'h-7 w-7' }) => {
  switch (product) {
    case 'paddy':
      return (
        <svg viewBox="0 0 32 32" fill="none" className={className} aria-hidden="true">
          <path d="M16 28V7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path
            d="M16 10C12.5 10 10 7.5 10 4.5C13 4.5 15.5 6.8 16 10Z"
            fill="currentColor"
            fillOpacity="0.22"
            stroke="currentColor"
            strokeWidth="1.75"
            strokeLinejoin="round"
          />
          <path
            d="M16 14C19.5 14 22 11.5 22 8.5C19 8.5 16.5 10.8 16 14Z"
            fill="currentColor"
            fillOpacity="0.22"
            stroke="currentColor"
            strokeWidth="1.75"
            strokeLinejoin="round"
          />
          <path
            d="M16 17.5C12.2 17.5 9.5 15 9.5 11.8C12.7 11.8 15.5 14.2 16 17.5Z"
            fill="currentColor"
            fillOpacity="0.22"
            stroke="currentColor"
            strokeWidth="1.75"
            strokeLinejoin="round"
          />
          <path
            d="M16 21.5C19.8 21.5 22.5 19 22.5 15.8C19.3 15.8 16.5 18.2 16 21.5Z"
            fill="currentColor"
            fillOpacity="0.22"
            stroke="currentColor"
            strokeWidth="1.75"
            strokeLinejoin="round"
          />
          <path
            d="M16 25C12.5 25 10 22.6 10 19.6C13 19.6 15.4 21.8 16 25Z"
            fill="currentColor"
            fillOpacity="0.22"
            stroke="currentColor"
            strokeWidth="1.75"
            strokeLinejoin="round"
          />
        </svg>
      );

    case 'rice':
      return (
        <svg viewBox="0 0 32 32" fill="none" className={className} aria-hidden="true">
          <path
            d="M5 17H27C27 23.075 22.075 27.5 16 27.5C9.925 27.5 5 23.075 5 17Z"
            fill="currentColor"
            fillOpacity="0.18"
            stroke="currentColor"
            strokeWidth="1.9"
            strokeLinejoin="round"
          />
          <path d="M11 27.5H21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <ellipse
            cx="12"
            cy="12.5"
            rx="2.8"
            ry="1.5"
            transform="rotate(-22 12 12.5)"
            fill="currentColor"
            fillOpacity="0.28"
            stroke="currentColor"
            strokeWidth="1.5"
          />
          <ellipse
            cx="16.5"
            cy="9.5"
            rx="2.8"
            ry="1.5"
            transform="rotate(14 16.5 9.5)"
            fill="currentColor"
            fillOpacity="0.28"
            stroke="currentColor"
            strokeWidth="1.5"
          />
          <ellipse
            cx="20.5"
            cy="13"
            rx="2.6"
            ry="1.4"
            transform="rotate(28 20.5 13)"
            fill="currentColor"
            fillOpacity="0.28"
            stroke="currentColor"
            strokeWidth="1.5"
          />
          <path
            d="M7.5 17C8.2 13.8 11.7 11.5 16 11.5C20.3 11.5 23.8 13.8 24.5 17"
            stroke="currentColor"
            strokeWidth="1.75"
            strokeLinecap="round"
          />
        </svg>
      );

    case 'wheat':
      return (
        <svg viewBox="0 0 32 32" fill="none" className={className} aria-hidden="true">
          <path d="M16 28V8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M16 4L14 7.5H18L16 4Z" fill="currentColor" />
          <path
            d="M16 12C13.2 11.5 11.2 9.4 11.5 6.8C14 7.2 15.8 9.2 16 12Z"
            fill="currentColor"
            fillOpacity="0.25"
            stroke="currentColor"
            strokeWidth="1.7"
          />
          <path
            d="M16 12C18.8 11.5 20.8 9.4 20.5 6.8C18 7.2 16.2 9.2 16 12Z"
            fill="currentColor"
            fillOpacity="0.25"
            stroke="currentColor"
            strokeWidth="1.7"
          />
          <path
            d="M16 17.5C12.8 17 10.6 14.7 11 11.8C13.8 12.2 15.8 14.4 16 17.5Z"
            fill="currentColor"
            fillOpacity="0.25"
            stroke="currentColor"
            strokeWidth="1.7"
          />
          <path
            d="M16 17.5C19.2 17 21.4 14.7 21 11.8C18.2 12.2 16.2 14.4 16 17.5Z"
            fill="currentColor"
            fillOpacity="0.25"
            stroke="currentColor"
            strokeWidth="1.7"
          />
          <path
            d="M16 23C12.8 22.5 10.8 20.2 11.2 17.4C13.8 17.8 15.7 20 16 23Z"
            fill="currentColor"
            fillOpacity="0.25"
            stroke="currentColor"
            strokeWidth="1.7"
          />
          <path
            d="M16 23C19.2 22.5 21.2 20.2 20.8 17.4C18.2 17.8 16.3 20 16 23Z"
            fill="currentColor"
            fillOpacity="0.25"
            stroke="currentColor"
            strokeWidth="1.7"
          />
        </svg>
      );

    case 'bosta':
    case 'bosta_50':
    case 'bosta_30':
      return (
        <svg viewBox="0 0 32 32" fill="none" className={className} aria-hidden="true">
          <path
            d="M11.5 6.5L13.5 9.5H18.5L20.5 6.5C19 5.5 17.5 5 16 5C14.5 5 13 5.5 11.5 6.5Z"
            fill="currentColor"
            fillOpacity="0.2"
            stroke="currentColor"
            strokeWidth="1.75"
            strokeLinejoin="round"
          />
          <path
            d="M12.5 9.5H19.5L23.5 16C25 18.5 25.2 22.2 23.6 24.8C22.4 26.6 20 27.5 16 27.5C12 27.5 9.6 26.6 8.4 24.8C6.8 22.2 7 18.5 8.5 16L12.5 9.5Z"
            fill="currentColor"
            fillOpacity="0.16"
            stroke="currentColor"
            strokeWidth="1.85"
            strokeLinejoin="round"
          />
          <path d="M11 10.5H21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path
            d="M12.5 18.5H19.5M13.5 22H18.5"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinecap="round"
          />
        </svg>
      );
  }
};

const BANGLA_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];

export function toBanglaDigits(value: string | number): string {
  return String(value).replace(/\d/g, (d) => BANGLA_DIGITS[Number(d)]);
}

export function formatBags(val: number): string {
  return toBanglaDigits(Math.round(val).toLocaleString('en-US'));
}

export function formatMetricTons(val: number): string {
  return toBanglaDigits(
    val.toLocaleString('en-US', {
      minimumFractionDigits: 3,
      maximumFractionDigits: 3,
    })
  );
}

export function todayIsoDate(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}
