import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  ClipboardList,
  Clock,
  Download,
  FileSpreadsheet,
  Minus,
  PackageMinus,
  Plus,
  RefreshCw,
  Search,
  Trash2,
  Truck,
} from 'lucide-react';
import {
  PRODUCTS,
  PRODUCT_MAP,
  inferDefaultProductFromCategory,
  type DeliveryOrder,
  type GasAppData,
  type GasBridgeStatus,
  type GrainTransaction,
  type ProductCategory,
  type TransactionType,
} from '../types/grain';
import { itemNameBnToProduct, parseGasNumber } from '../shared/gasBridge';
import { ProductIcon, formatBags, formatMetricTons } from './GrainIcons';

export type LedgerSubTab = 'ledger' | 'pending_dos' | 'distributed_dos' | 'dispatches';

interface ActionResult {
  ok: boolean;
  message?: string;
  error?: string;
}

interface LedgerViewProps {
  transactions: GrainTransaction[];
  pendingDos: DeliveryOrder[];
  distributedDos: DeliveryOrder[];
  gasData?: GasAppData | null;
  gasBridgeStatus?: GasBridgeStatus;
  initialSubTab?: LedgerSubTab;
  isSyncingDos?: boolean;
  onSyncExternalDos?: () => void;
  onStartDoDistribution?: (product: ProductCategory) => void;
  onMarkDoDistributed?: (id: string) => void;
  onDeleteDeliveryOrder?: (id: string) => void;
  onDeleteTransaction: (id: string) => void;
  onDeleteGasRecord?: (
    sheetName: string,
    rowIdx: number,
    expectedId?: string
  ) => Promise<ActionResult>;
  onExportCsv: (rows: GrainTransaction[]) => void;
}

interface UnifiedGasTx extends GrainTransaction {
  gasSheet?: 'Khamal_Master' | 'Empty_Bags' | 'Bag_Transactions' | 'Transactions';
  gasRowIdx?: number;
  gasExpectedId?: string;
  subKind?: 'receipt' | 'do' | 'invoice' | 'mill' | 'shortage' | 'bag_receipt' | 'bag_issue';
}

export const LedgerView: React.FC<LedgerViewProps> = ({
  transactions,
  pendingDos,
  distributedDos,
  gasData = null,
  gasBridgeStatus = 'idle',
  initialSubTab = 'ledger',
  isSyncingDos = false,
  onSyncExternalDos,
  onStartDoDistribution,
  onMarkDoDistributed,
  onDeleteDeliveryOrder,
  onDeleteTransaction,
  onDeleteGasRecord,
  onExportCsv,
}) => {
  const [subTab, setSubTab] = useState<LedgerSubTab>(initialSubTab);
  const [typeFilter, setTypeFilter] = useState<'all' | TransactionType>('all');
  const [productFilter, setProductFilter] = useState<'all' | ProductCategory>('all');
  const [channelFilter, setChannelFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [doSearchQuery, setDoSearchQuery] = useState<string>('');
  const [doProductFilter, setDoProductFilter] = useState<'all' | ProductCategory>('all');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  useEffect(() => {
    setSubTab(initialSubTab);
  }, [initialSubTab]);

  const isGasLive = gasBridgeStatus === 'connected' && Boolean(gasData);

  // Build unified ledger entries when live GAS is connected
  const activeTransactions = useMemo<UnifiedGasTx[]>(() => {
    if (!isGasLive || !gasData) return transactions;

    const list: UnifiedGasTx[] = [];

    const khamalProdMap = new Map(
      (gasData.masterGrain || []).map((m) => [String(m.khamalId), itemNameBnToProduct(m.item)])
    );

    // 1. Master Khamals (Receipts)
    (gasData.masterGrain || []).forEach((m, idx) => {
      list.push({
        id: `gas-mg-${m.rowIdx}-${m.khamalId}-${idx}`,
        batchId: `gas-${m.khamalId}`,
        type: 'receipt',
        product: itemNameBnToProduct(m.item),
        godownNo: String(m.godown || '০১'),
        khamalNo: String(m.khamalId),
        bags: Math.round(parseGasNumber(m.initBags)),
        metricTons: Number(parseGasNumber(m.initWeight).toFixed(4)),
        channel: m.category || 'প্রাপ্তি',
        referenceNo: m.uniqueId || '',
        date: m.entryDate || '',
        note: m.remarks || '',
        createdAt: m.entryDate || '',
        gasSheet: 'Khamal_Master',
        gasRowIdx: m.rowIdx,
        gasExpectedId: String(m.khamalId || ''),
        subKind: 'receipt',
      });
    });

    // 2. DO Issues
    (gasData.issueList || []).forEach((r, idx) => {
      const cat = r.khath || 'ডিও বিতরণ';
      const inferredProd =
        (r.khamalId ? khamalProdMap.get(String(r.khamalId)) : undefined) ||
        inferDefaultProductFromCategory(cat);
      list.push({
        id: `gas-iss-${r.rowIdx}-${r.id || idx}`,
        batchId: `gas-iss-${r.id}`,
        type: 'distribution',
        product: inferredProd,
        godownNo: '-',
        khamalNo: String(r.khamalId || '-'),
        bags: Math.round(parseGasNumber(r.bags)),
        metricTons: Number(parseGasNumber(r.weight).toFixed(4)),
        channel: cat,
        doNumber: String(r.doNo || ''),
        referenceNo: r.reference || '',
        date: r.date || '',
        note: r.reference || '',
        createdAt: r.date || '',
        gasSheet: 'Transactions',
        gasRowIdx: r.rowIdx,
        gasExpectedId: r.id,
        subKind: 'do',
      });
    });

    // 3. Invoice & Mill Dispatches
    (gasData.dispatchList || []).forEach((d, idx) => {
      const isMill = d.type === 'Mill';
      const inferredProd =
        (d.khamalId ? khamalProdMap.get(String(d.khamalId)) : undefined) ||
        (isMill ? 'paddy' : 'rice');
      list.push({
        id: `gas-disp-${d.rowIdx}-${d.id || idx}`,
        batchId: `gas-disp-${d.id}`,
        type: 'distribution',
        product: inferredProd,
        godownNo: '-',
        khamalNo: String(d.khamalId || '-'),
        bags: Math.round(parseGasNumber(d.bags)),
        metricTons: Number(parseGasNumber(d.weight).toFixed(4)),
        channel: isMill ? `মিলে ক্রাশিং (${d.party || ''})` : `ইনভয়েস (${d.party || ''})`,
        doNumber: d.docNo ? `${isMill ? 'মিল' : 'ইনভয়েস'}: ${d.docNo}` : '',
        referenceNo: d.reference || '',
        date: d.date || '',
        note: d.reference || d.party || '',
        createdAt: d.date || '',
        gasSheet: 'Transactions',
        gasRowIdx: d.rowIdx,
        gasExpectedId: d.id,
        subKind: isMill ? 'mill' : 'invoice',
      });
    });

    // 4. Discrepancies (Shortages)
    (gasData.discList || []).forEach((sc, idx) => {
      const inferredProd =
        (sc.khamalId ? khamalProdMap.get(String(sc.khamalId)) : undefined) || 'rice';
      list.push({
        id: `gas-disc-${sc.rowIdx}-${sc.id || idx}`,
        batchId: `gas-disc-${sc.id}`,
        type: 'shortage',
        product: inferredProd,
        godownNo: '-',
        khamalNo: String(sc.khamalId || '-'),
        bags: Math.round(parseGasNumber(sc.bags)),
        metricTons: Number(parseGasNumber(sc.weight).toFixed(4)),
        channel: 'খামাল ঘাটতি (শর্টেজ)',
        referenceNo: '',
        date: sc.date || '',
        note: sc.remarks || '',
        createdAt: sc.date || '',
        gasSheet: 'Transactions',
        gasRowIdx: sc.rowIdx,
        gasExpectedId: sc.id,
        subKind: 'shortage',
      });
    });

    // 5. Empty Bag Masters
    (gasData.masterEmptyBags || []).forEach((eb, idx) => {
      list.push({
        id: `gas-ebm-${eb.rowIdx}-${eb.id || idx}`,
        batchId: `gas-ebm-${eb.id}`,
        type: 'receipt',
        product: itemNameBnToProduct(eb.bagType),
        godownNo: String(eb.godown || '০১'),
        khamalNo: String(eb.khamalNo || eb.bagType),
        bags: Math.round(parseGasNumber(eb.initialBags)),
        metricTons: 0,
        channel: 'খালি বস্তা প্রাপ্তি',
        referenceNo: '',
        date: eb.entryDate || '',
        note: eb.bagType || '',
        createdAt: eb.entryDate || '',
        gasSheet: 'Empty_Bags',
        gasRowIdx: eb.rowIdx,
        gasExpectedId: eb.id,
        subKind: 'bag_receipt',
      });
    });

    // 6. Empty Bag Issues
    (gasData.bagIssueList || []).forEach((bi, idx) => {
      list.push({
        id: `gas-ebi-${bi.rowIdx}-${bi.id || idx}`,
        batchId: `gas-ebi-${bi.id}`,
        type: 'distribution',
        product: itemNameBnToProduct(bi.bagType),
        godownNo: String(bi.godown || '০১'),
        khamalNo: String(bi.khamalNo || bi.bagType),
        bags: Math.round(parseGasNumber(bi.bags)),
        metricTons: 0,
        channel: 'খালি বস্তা বিতরণ',
        referenceNo: '',
        date: bi.issueDate || '',
        note: bi.bagType || '',
        createdAt: bi.issueDate || '',
        gasSheet: 'Bag_Transactions',
        gasRowIdx: bi.rowIdx,
        gasExpectedId: bi.id,
        subKind: 'bag_issue',
      });
    });

    return list.sort((a, b) => (b.date || '').localeCompare(a.date || ''));
  }, [isGasLive, gasData, transactions]);

  const dispatchAndShortageCount = useMemo(() => {
    if (!isGasLive || !gasData) return 0;
    return (
      (gasData.dispatchList?.length || 0) +
      (gasData.discList?.length || 0) +
      (gasData.bagIssueList?.length || 0)
    );
  }, [isGasLive, gasData]);

  const uniqueChannels = useMemo(() => {
    const set = new Set<string>();
    activeTransactions.forEach((tx) => {
      if (tx.channel) set.add(tx.channel);
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b, 'bn'));
  }, [activeTransactions]);

  const filtered = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return activeTransactions.filter((tx) => {
      if (typeFilter !== 'all' && tx.type !== typeFilter) return false;
      if (productFilter !== 'all' && tx.product !== productFilter) return false;
      if (channelFilter !== 'all' && tx.channel !== channelFilter) return false;
      if (q) {
        const hay =
          `${tx.godownNo} ${tx.khamalNo} ${tx.channel} ${tx.doNumber || ''} ${tx.referenceNo} ${tx.note}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [activeTransactions, typeFilter, productFilter, channelFilter, searchQuery]);

  const filteredPendingDos = useMemo(() => {
    const q = doSearchQuery.trim().toLowerCase();
    return pendingDos.filter((d) => {
      if (doProductFilter !== 'all' && d.product !== doProductFilter) return false;
      if (q) {
        const hay = `${d.doNumber} ${d.category} ${d.recipient}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [pendingDos, doSearchQuery, doProductFilter]);

  const filteredDistributedDos = useMemo(() => {
    const q = doSearchQuery.trim().toLowerCase();
    return distributedDos.filter((d) => {
      if (doProductFilter !== 'all' && d.product !== doProductFilter) return false;
      if (q) {
        const hay =
          `${d.doNumber} ${d.category} ${d.recipient} ${(d.distributedFrom || []).join(' ')}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [distributedDos, doSearchQuery, doProductFilter]);

  const channelSummary = useMemo(() => {
    const map = new Map<
      string,
      {
        channel: string;
        type: TransactionType;
        product: ProductCategory;
        count: number;
        bags: number;
        mt: number;
      }
    >();

    for (const tx of filtered) {
      const key = `${tx.type}::${tx.product}::${tx.channel}`;
      const existing = map.get(key);
      if (existing) {
        existing.count += 1;
        existing.bags += tx.bags;
        existing.mt = Number((existing.mt + tx.metricTons).toFixed(4));
      } else {
        map.set(key, {
          channel: tx.channel,
          type: tx.type,
          product: tx.product,
          count: 1,
          bags: tx.bags,
          mt: tx.metricTons,
        });
      }
    }
    return Array.from(map.values());
  }, [filtered]);

  const typeLabel = (t: TransactionType) =>
    t === 'receipt' ? 'প্রাপ্তি' : t === 'distribution' ? 'বিতরণ' : 'খামাল শর্টেজ';

  const handleConfirmDelete = async (tx: UnifiedGasTx) => {
    if (tx.gasSheet && tx.gasRowIdx !== undefined && onDeleteGasRecord) {
      setDeletingId(tx.id);
      try {
        await onDeleteGasRecord(tx.gasSheet, tx.gasRowIdx, tx.gasExpectedId || '');
      } finally {
        setDeletingId(null);
        setConfirmDeleteId(null);
      }
      return;
    }
    onDeleteTransaction(tx.id);
    setConfirmDeleteId(null);
  };

  return (
    <div className="space-y-5">
      {/* Top Sub-Navigation */}
      <div
        className={`grid ${
          isGasLive ? 'grid-cols-2 sm:grid-cols-4' : 'grid-cols-3'
        } gap-1.5 p-1 rounded-2xl bg-slate-200/75 border border-slate-200`}
      >
        <button
          type="button"
          onClick={() => setSubTab('ledger')}
          className={`min-h-[42px] rounded-xl px-3 py-2 text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
            subTab === 'ledger'
              ? 'bg-white text-slate-900 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <ClipboardList className="h-4 w-4 shrink-0" />
          <span className="truncate">সব লেনদেন ({activeTransactions.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setSubTab('pending_dos')}
          className={`min-h-[42px] rounded-xl px-3 py-2 text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
            subTab === 'pending_dos'
              ? 'bg-white text-rose-800 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Clock className="h-4 w-4 shrink-0" />
          <span className="truncate">পেন্ডিং ডিও ({pendingDos.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setSubTab('distributed_dos')}
          className={`min-h-[42px] rounded-xl px-3 py-2 text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
            subTab === 'distributed_dos'
              ? 'bg-white text-emerald-800 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <CheckCircle2 className="h-4 w-4 shrink-0" />
          <span className="truncate">বিতরণকৃত ডিও ({distributedDos.length})</span>
        </button>

        {isGasLive && (
          <button
            type="button"
            onClick={() => setSubTab('dispatches')}
            className={`min-h-[42px] rounded-xl px-3 py-2 text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
              subTab === 'dispatches'
                ? 'bg-white text-indigo-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Truck className="h-4 w-4 shrink-0" />
            <span className="truncate">মিল/ইনভয়েস/ঘাটতি ({dispatchAndShortageCount})</span>
          </button>
        )}
      </div>

      {/* TAB 1: FULL LEDGER */}
      {subTab === 'ledger' && (
        <>
          <section className="rounded-2xl border border-slate-200 bg-white p-4 sm:p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-lg font-bold text-slate-900">
                  চ্যানেল, ডিও ও লেনদেনের পূর্ণাঙ্গ রেকর্ড
                </h2>
                <p className="text-xs text-slate-500 mt-0.5 tabular-nums">
                  মোট এন্ট্রি: {filtered.length}টি
                  {isGasLive && ' · গুগল শিট লাইভ ডেটা'}
                </p>
              </div>

              <button
                type="button"
                onClick={() => onExportCsv(filtered)}
                disabled={filtered.length === 0}
                className="min-h-[40px] inline-flex items-center justify-center gap-2 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 disabled:opacity-50 px-4 py-2 text-xs font-bold text-slate-800 whitespace-nowrap cursor-pointer"
              >
                <Download className="h-3.5 w-3.5 text-emerald-700" />
                <span>CSV রিপোর্ট ডাউনলোড</span>
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-100 border border-slate-200">
                {(
                  [
                    { id: 'all', label: 'সব ধরন' },
                    { id: 'receipt', label: 'প্রাপ্তি (+)' },
                    { id: 'distribution', label: 'বিতরণ (-)' },
                    { id: 'shortage', label: 'শর্টেজ (!)' },
                  ] as Array<{ id: 'all' | TransactionType; label: string }>
                ).map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => setTypeFilter(t.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                      typeFilter === t.id
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>

              <div className="flex flex-wrap items-center gap-1 p-1 rounded-xl bg-slate-100 border border-slate-200">
                <button
                  type="button"
                  onClick={() => setProductFilter('all')}
                  className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                    productFilter === 'all'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  সব পণ্য
                </button>
                {PRODUCTS.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setProductFilter(p.id)}
                    className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                      productFilter === p.id
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {p.shortBn}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="relative">
                <Search className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="ডিও নং, গুদাম, খামাল বা মন্তব্য খুঁজুন..."
                  className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-slate-50/50 pl-9 pr-3 py-2 text-sm text-slate-900 focus:bg-white focus:border-emerald-700 focus:outline-none"
                />
              </div>

              <select
                aria-label="চ্যানেল ফিল্টার"
                value={channelFilter}
                onChange={(e) => setChannelFilter(e.target.value)}
                className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm font-medium text-slate-800 focus:border-emerald-700 focus:outline-none"
              >
                <option value="all">সকল চ্যানেল / খাত</option>
                {uniqueChannels.map((ch) => (
                  <option key={ch} value={ch}>
                    {ch}
                  </option>
                ))}
              </select>
            </div>
          </section>

          {channelSummary.length > 0 && (
            <section className="rounded-2xl border border-slate-200 bg-white p-4 sm:p-5">
              <h3 className="text-sm font-bold text-slate-900 mb-3">খাত / চ্যানেলভিত্তিক সারসংক্ষেপ</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-500">
                      <th className="py-2 pr-3 font-semibold">পণ্য</th>
                      <th className="py-2 pr-3 font-semibold">ধরন</th>
                      <th className="py-2 pr-3 font-semibold">চ্যানেল / খাত</th>
                      <th className="py-2 pr-3 font-semibold text-right">এন্ট্রি</th>
                      <th className="py-2 pr-3 font-semibold text-right">মে.টন</th>
                      <th className="py-2 font-semibold text-right">বস্তা</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {channelSummary.map((row, idx) => {
                      const pMeta = PRODUCT_MAP[row.product];
                      const colorCls =
                        row.type === 'receipt'
                          ? 'text-emerald-700'
                          : row.type === 'distribution'
                            ? 'text-rose-700'
                            : 'text-amber-700';
                      return (
                        <tr key={`${row.channel}-${row.product}-${row.type}-${idx}`}>
                          <td className="py-2.5 pr-3 font-semibold text-slate-800 whitespace-nowrap">
                            {pMeta.shortBn}
                          </td>
                          <td className={`py-2.5 pr-3 font-semibold whitespace-nowrap ${colorCls}`}>
                            {typeLabel(row.type)}
                          </td>
                          <td className="py-2.5 pr-3 text-slate-700">{row.channel}</td>
                          <td className="py-2.5 pr-3 text-right tabular-nums text-slate-600">
                            {row.count}
                          </td>
                          <td className="py-2.5 pr-3 text-right font-mono font-bold tabular-nums text-slate-900">
                            {formatMetricTons(row.mt)}
                          </td>
                          <td className="py-2.5 text-right font-semibold tabular-nums text-slate-500">
                            {formatBags(row.bags)}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </section>
          )}

          {filtered.length === 0 ? (
            <div className="rounded-2xl border border-slate-200 bg-white p-10 text-center">
              <FileSpreadsheet className="h-8 w-8 text-slate-300 mx-auto" />
              <p className="mt-3 text-sm font-semibold text-slate-700">কোনো লেনদেনের রেকর্ড নেই</p>
              <p className="mt-1 text-xs text-slate-500">
                নতুন প্রাপ্তি বা ডিও বিতরণ যোগ করলে এখানে পূর্ণাঙ্গ বিবরণ দেখা যাবে।
              </p>
            </div>
          ) : (
            <section className="rounded-2xl border border-slate-200 bg-white divide-y divide-slate-100 overflow-hidden">
              {filtered.map((tx) => {
                const meta = PRODUCT_MAP[tx.product];
                const isRec = tx.type === 'receipt';
                const isShortage = tx.type === 'shortage';

                return (
                  <div
                    key={tx.id}
                    className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/70 transition-colors"
                  >
                    <div className="flex items-start gap-3 min-w-0">
                      <div
                        className={`h-10 w-10 rounded-xl flex items-center justify-center shrink-0 ${
                          isRec
                            ? 'bg-emerald-50 text-emerald-700'
                            : isShortage
                              ? 'bg-amber-50 text-amber-700'
                              : 'bg-rose-50 text-rose-700'
                        }`}
                      >
                        {isRec ? (
                          <Plus className="h-5 w-5" />
                        ) : isShortage ? (
                          <AlertTriangle className="h-5 w-5" />
                        ) : (
                          <Minus className="h-5 w-5" />
                        )}
                      </div>

                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-sm font-bold text-slate-900">
                          <span className="inline-flex items-center gap-1">
                            <ProductIcon product={tx.product} className={`h-4 w-4 ${meta.textColorClass}`} />
                            <span>{meta.nameBn}</span>
                          </span>
                          <span aria-hidden="true" className="text-slate-300">
                            ·
                          </span>
                          <span>
                            {tx.godownNo !== '-' ? `${tx.godownNo} / ` : 'খামাল '}
                            {tx.khamalNo}
                          </span>
                        </div>

                        <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-slate-600">
                          <span
                            className={`font-semibold ${
                              isRec
                                ? 'text-emerald-800'
                                : isShortage
                                  ? 'text-amber-800'
                                  : 'text-rose-800'
                            }`}
                          >
                            {typeLabel(tx.type)}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span className="font-medium text-slate-800">{tx.channel}</span>
                          {tx.doNumber && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="font-mono font-semibold text-slate-800">
                                {tx.doNumber}
                              </span>
                            </>
                          )}
                          {tx.date && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="font-mono tabular-nums text-slate-500">{tx.date}</span>
                            </>
                          )}
                        </div>

                        {tx.note && <p className="mt-1 text-xs text-slate-500">{tx.note}</p>}
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-4 shrink-0 pl-13 sm:pl-0">
                      <div className="text-left sm:text-right tabular-nums">
                        {meta.tracksWeight ? (
                          <>
                            <div
                              className={`text-sm font-extrabold ${
                                isRec
                                  ? 'text-emerald-800'
                                  : isShortage
                                    ? 'text-amber-800'
                                    : 'text-rose-800'
                              }`}
                            >
                              {isRec ? '+' : '-'}
                              {formatMetricTons(tx.metricTons)} মে.টন
                            </div>
                            <div className="text-xs font-mono text-slate-500">
                              {isRec ? '+' : '-'}
                              {formatBags(tx.bags)} বস্তা
                            </div>
                          </>
                        ) : (
                          <div
                            className={`text-sm font-extrabold ${
                              isRec
                                ? 'text-emerald-800'
                                : isShortage
                                  ? 'text-amber-800'
                                  : 'text-rose-800'
                            }`}
                          >
                            {isRec ? '+' : '-'}
                            {formatBags(tx.bags)} বস্তা
                          </div>
                        )}
                      </div>

                      {confirmDeleteId === tx.id ? (
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            disabled={deletingId === tx.id}
                            onClick={() => void handleConfirmDelete(tx)}
                            className="px-2.5 py-1.5 rounded-lg bg-rose-600 text-white text-xs font-bold hover:bg-rose-700 disabled:opacity-50 cursor-pointer"
                          >
                            {deletingId === tx.id ? '...' : 'মুছুন'}
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteId(null)}
                            className="px-2 py-1.5 rounded-lg border border-slate-200 bg-white text-xs text-slate-600 cursor-pointer"
                          >
                            বাতিল
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteId(tx.id)}
                          className="min-h-[38px] min-w-[38px] rounded-lg flex items-center justify-center text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                          aria-label="এন্ট্রি মুছুন"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </section>
          )}
        </>
      )}

      {/* TAB 2 & TAB 3: PENDING DOs & DISTRIBUTED DOs */}
      {(subTab === 'pending_dos' || subTab === 'distributed_dos') && (
        <>
          <section className="rounded-2xl border border-slate-200 bg-white p-4 sm:p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-lg font-bold text-slate-900">
                  {subTab === 'pending_dos'
                    ? 'অপেক্ষমাণ (পেন্ডিং) ডিও তালিকা'
                    : 'বিতরণকৃত ডিও তালিকা'}
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  {subTab === 'pending_dos'
                    ? 'মেইন অ্যাপের গুগল শিট ও লিংক করা ওয়েব অ্যাপের অপেক্ষমাণ ডিও। বিতরণ সম্পন্ন হলে পেন্ডিং থেকে সরে যাবে।'
                    : 'যেসকল ডিও-এর বিতরণ সম্পন্ন হয়েছে তার পূর্ণাঙ্গ তালিকা (এগুলো পেন্ডিংয়ে দেখানো হয় না)।'}
                </p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {onSyncExternalDos && (
                  <button
                    type="button"
                    onClick={onSyncExternalDos}
                    disabled={isSyncingDos}
                    className="min-h-[40px] inline-flex items-center gap-1.5 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 px-3.5 py-2 text-xs font-bold text-slate-800 cursor-pointer"
                  >
                    <RefreshCw className={`h-3.5 w-3.5 ${isSyncingDos ? 'animate-spin' : ''}`} />
                    <span>{isSyncingDos ? 'সিঙ্ক হচ্ছে...' : 'ওয়েব অ্যাপ সিঙ্ক'}</span>
                  </button>
                )}
                {subTab === 'pending_dos' && onStartDoDistribution && pendingDos.length > 0 && (
                  <button
                    type="button"
                    onClick={() => onStartDoDistribution(pendingDos[0].product)}
                    className="min-h-[40px] inline-flex items-center gap-1.5 rounded-xl bg-[#B91C1C] hover:bg-red-800 px-3.5 py-2 text-xs font-bold text-white cursor-pointer"
                  >
                    <Minus className="h-3.5 w-3.5" />
                    <span>ডিও বিতরণ করুন</span>
                  </button>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="relative">
                <Search className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={doSearchQuery}
                  onChange={(e) => setDoSearchQuery(e.target.value)}
                  placeholder="ডিও নম্বর, খাত বা প্রাপক খুঁজুন..."
                  className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-slate-50/50 pl-9 pr-3 py-2 text-sm text-slate-900 focus:bg-white focus:border-emerald-700 focus:outline-none"
                />
              </div>

              <div className="flex flex-wrap items-center gap-1 p-1 rounded-xl bg-slate-100 border border-slate-200">
                <button
                  type="button"
                  onClick={() => setDoProductFilter('all')}
                  className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
                    doProductFilter === 'all'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  সব পণ্য
                </button>
                {PRODUCTS.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setDoProductFilter(p.id)}
                    className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
                      doProductFilter === p.id
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {p.shortBn}
                  </button>
                ))}
              </div>
            </div>
          </section>

          {subTab === 'pending_dos' && (
            filteredPendingDos.length === 0 ? (
              <div className="rounded-2xl border border-slate-200 bg-white p-10 text-center">
                <Clock className="h-8 w-8 text-slate-300 mx-auto" />
                <p className="mt-3 text-sm font-semibold text-slate-700">কোনো পেন্ডিং ডিও নেই</p>
                <p className="mt-1 text-xs text-slate-500">
                  মেইন ওয়েব অ্যাপে নতুন ডিও এন্ট্রি হলে বা সেটিংস থেকে যোগ করলে এখানে পেন্ডিং তালিকায় দেখাবে।
                </p>
              </div>
            ) : (
              <section className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {filteredPendingDos.map((d) => {
                  const meta = PRODUCT_MAP[d.product];
                  const remMt = Math.max(0, Number((d.totalMt - d.deliveredMt).toFixed(4)));
                  const remBags = Math.max(0, d.totalBags - d.deliveredBags);
                  return (
                    <div
                      key={d.id}
                      className="rounded-2xl border border-slate-200 bg-white p-4 flex flex-col justify-between gap-3"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-start gap-2.5 min-w-0">
                          <div
                            className={`h-10 w-10 rounded-xl ${meta.softBgClass} ${meta.textColorClass} flex items-center justify-center shrink-0`}
                          >
                            <ProductIcon product={d.product} className="h-5 w-5" />
                          </div>
                          <div className="min-w-0">
                            <div className="font-mono text-sm font-extrabold text-slate-900 truncate">
                              {d.doNumber}
                            </div>
                            <div className="text-xs text-slate-600 truncate">
                              {meta.nameBn} · {d.category}
                            </div>
                            {d.recipient && (
                              <div className="text-xs text-slate-500 truncate mt-0.5">
                                প্রাপক: {d.recipient}
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="text-right shrink-0 tabular-nums">
                          <div className="text-sm font-extrabold text-[#B91C1C]">
                            {meta.tracksWeight
                              ? `${formatMetricTons(remMt)} মে.টন`
                              : `${formatBags(remBags)} বস্তা`}
                          </div>
                          <div className="text-[11px] text-slate-500">
                            বাকি প্রাপ্য ({d.source === 'apps_script' ? 'মেইন শিট' : 'লোকাল'})
                          </div>
                        </div>
                      </div>

                      <div className="pt-2.5 border-t border-slate-100 flex items-center justify-between gap-2">
                        <span className="text-[11px] font-mono text-slate-500">{d.date}</span>
                        <div className="flex items-center gap-2">
                          {!isGasLive && onMarkDoDistributed && (
                            <button
                              type="button"
                              onClick={() => onMarkDoDistributed(d.id)}
                              className="px-2.5 py-1.5 rounded-lg border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 text-[11px] font-bold text-emerald-800 cursor-pointer"
                            >
                              বিতরণকৃত চিহ্নিত করুন
                            </button>
                          )}
                          {onStartDoDistribution && (
                            <button
                              type="button"
                              onClick={() => onStartDoDistribution(d.product)}
                              className="px-3 py-1.5 rounded-lg bg-[#B91C1C] hover:bg-red-800 text-[11px] font-bold text-white cursor-pointer"
                            >
                              বিতরণ করুন
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </section>
            )
          )}

          {subTab === 'distributed_dos' && (
            filteredDistributedDos.length === 0 ? (
              <div className="rounded-2xl border border-slate-200 bg-white p-10 text-center">
                <CheckCircle2 className="h-8 w-8 text-slate-300 mx-auto" />
                <p className="mt-3 text-sm font-semibold text-slate-700">
                  এখনও কোনো বিতরণকৃত ডিও নেই
                </p>
                <p className="mt-1 text-xs text-slate-500">
                  পেন্ডিং ডিও বিতরণ সম্পন্ন হলে এখানে আলাদা তালিকায় দেখা যাবে।
                </p>
              </div>
            ) : (
              <section className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {filteredDistributedDos.map((d, idx) => {
                  const meta = PRODUCT_MAP[d.product];
                  const issueRow = isGasLive ? gasData?.issueList?.find((r) => `gas-iss-${r.id}` === d.id || r.doNo === d.doNumber) : undefined;
                  return (
                    <div
                      key={`${d.id}-${idx}`}
                      className="rounded-2xl border border-emerald-200 bg-white p-4 flex flex-col justify-between gap-3"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-start gap-2.5 min-w-0">
                          <div
                            className={`h-10 w-10 rounded-xl ${meta.softBgClass} ${meta.textColorClass} flex items-center justify-center shrink-0`}
                          >
                            <ProductIcon product={d.product} className="h-5 w-5" />
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-sm font-extrabold text-slate-900 truncate">
                                {d.doNumber}
                              </span>
                              <span className="text-[11px] font-bold text-emerald-800">
                                বিতরণকৃত
                              </span>
                            </div>
                            <div className="text-xs text-slate-600 truncate">
                              {meta.nameBn} · {d.category}
                            </div>
                            {d.recipient && (
                              <div className="text-xs text-slate-500 truncate mt-0.5">
                                প্রাপক/মন্তব্য: {d.recipient}
                              </div>
                            )}
                            {d.distributedFrom && d.distributedFrom.length > 0 && (
                              <div className="text-[11px] text-slate-600 mt-1">
                                <strong className="text-slate-800">{d.distributedFrom.join(', ')}</strong>
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="text-right shrink-0 tabular-nums">
                          <div className="text-sm font-extrabold text-emerald-800">
                            {meta.tracksWeight
                              ? `${formatMetricTons(d.deliveredMt || d.totalMt)} মে.টন`
                              : `${formatBags(d.deliveredBags || d.totalBags)} বস্তা`}
                          </div>
                          {meta.tracksWeight && (
                            <div className="text-[11px] text-slate-500">
                              {formatBags(d.deliveredBags || d.totalBags)} বস্তা
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="pt-2.5 border-t border-slate-100 flex items-center justify-between gap-2 text-[11px] text-slate-500">
                        <span className="font-mono">
                          বিতরণ তারিখ: {d.distributedAt ? d.distributedAt.slice(0, 10) : d.date}
                        </span>
                        {isGasLive && issueRow && onDeleteGasRecord ? (
                          <button
                            type="button"
                            onClick={() => void onDeleteGasRecord('Transactions', issueRow.rowIdx, issueRow.id)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 cursor-pointer"
                            aria-label="রেকর্ড মুছুন"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        ) : (
                          !isGasLive &&
                          onDeleteDeliveryOrder && (
                            <button
                              type="button"
                              onClick={() => onDeleteDeliveryOrder(d.id)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 cursor-pointer"
                              aria-label="ডিও মুছুন"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          )
                        )}
                      </div>
                    </div>
                  );
                })}
              </section>
            )
          )}
        </>
      )}

      {/* TAB 4: LIVE DISPATCHES (INVOICE/MILL), DISCREPANCIES & EMPTY BAG ISSUES */}
      {subTab === 'dispatches' && isGasLive && gasData && (
        <div className="space-y-5">
          {/* Invoice & Mill Dispatch List */}
          <section className="rounded-2xl border border-slate-200 bg-white overflow-hidden">
            <div className="px-4 sm:px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Truck className="h-4 w-4 text-indigo-700" />
                <h3 className="text-sm font-bold text-slate-900">
                  ইনভয়েস ও মিল প্রেরণ তালিকা ({gasData.dispatchList?.length || 0}টি)
                </h3>
              </div>
            </div>
            {!gasData.dispatchList?.length ? (
              <div className="p-6 text-center text-xs text-slate-500">
                কোনো ইনভয়েস বা মিল প্রেরণ রেকর্ড নেই।
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {gasData.dispatchList.map((d, idx) => (
                  <div
                    key={`${d.id}-${idx}`}
                    className="px-4 sm:px-5 py-3 flex items-center justify-between gap-3"
                  >
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-slate-900 truncate">
                        {d.type === 'Mill' ? 'মিল (ক্রাশিং)' : 'ইনভয়েস (চাল)'} ·{' '}
                        <span className="font-mono">{d.docNo}</span> · খামাল {d.khamalId}
                      </div>
                      <div className="text-[11px] text-slate-500 truncate mt-0.5">
                        {d.party}
                        {d.date ? ` · ${d.date}` : ''}
                        {d.reference ? ` · ${d.reference}` : ''}
                      </div>
                    </div>
                    <div className="flex items-center gap-3 shrink-0 tabular-nums">
                      <div className="text-right">
                        <div className="text-xs font-extrabold text-indigo-900">
                          {formatMetricTons(parseGasNumber(d.weight))} মে.টন
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {formatBags(parseGasNumber(d.bags))} বস্তা
                        </div>
                      </div>
                      {onDeleteGasRecord && (
                        <button
                          type="button"
                          onClick={() => void onDeleteGasRecord('Transactions', d.rowIdx, d.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 cursor-pointer"
                          aria-label="প্রেরণ মুছুন"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Discrepancy List */}
          <section className="rounded-2xl border border-slate-200 bg-white overflow-hidden">
            <div className="px-4 sm:px-5 py-3.5 border-b border-slate-100 flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-amber-700" />
              <h3 className="text-sm font-bold text-slate-900">
                খামাল ঘাটতি (শর্টেজ) রেকর্ড ({gasData.discList?.length || 0}টি)
              </h3>
            </div>
            {!gasData.discList?.length ? (
              <div className="p-6 text-center text-xs text-slate-500">কোনো ঘাটতি এন্ট্রি নেই।</div>
            ) : (
              <div className="divide-y divide-slate-100">
                {gasData.discList.map((sc, idx) => (
                  <div
                    key={`${sc.id}-${idx}`}
                    className="px-4 sm:px-5 py-3 flex items-center justify-between gap-3"
                  >
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-slate-900">খামাল {sc.khamalId}</div>
                      <div className="text-[11px] text-slate-500 truncate">
                        {sc.remarks || 'ঘাটতি'}
                        {sc.date ? ` · ${sc.date}` : ''}
                      </div>
                    </div>
                    <div className="flex items-center gap-3 shrink-0 tabular-nums">
                      <div className="text-right">
                        <div className="text-xs font-extrabold text-amber-800">
                          {formatMetricTons(parseGasNumber(sc.weight))} মে.টন
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {formatBags(parseGasNumber(sc.bags))} বস্তা
                        </div>
                      </div>
                      {onDeleteGasRecord && (
                        <button
                          type="button"
                          onClick={() => void onDeleteGasRecord('Transactions', sc.rowIdx, sc.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 cursor-pointer"
                          aria-label="ঘাটতি মুছুন"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Empty Bag Issue List */}
          <section className="rounded-2xl border border-slate-200 bg-white overflow-hidden">
            <div className="px-4 sm:px-5 py-3.5 border-b border-slate-100 flex items-center gap-2">
              <PackageMinus className="h-4 w-4 text-slate-700" />
              <h3 className="text-sm font-bold text-slate-900">
                খালি বস্তা বিতরণ তালিকা ({gasData.bagIssueList?.length || 0}টি)
              </h3>
            </div>
            {!gasData.bagIssueList?.length ? (
              <div className="p-6 text-center text-xs text-slate-500">
                কোনো খালি বস্তা বিতরণ এন্ট্রি নেই।
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {gasData.bagIssueList.map((bi, idx) => (
                  <div
                    key={`${bi.id}-${idx}`}
                    className="px-4 sm:px-5 py-3 flex items-center justify-between gap-3"
                  >
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-slate-900">
                        {bi.bagType} · গুদাম {bi.godown}
                      </div>
                      <div className="text-[11px] text-slate-500 truncate">
                        খামাল/বাবদ: {bi.khamalNo || '-'}
                        {bi.issueDate ? ` · ${bi.issueDate}` : ''}
                      </div>
                    </div>
                    <div className="flex items-center gap-3 shrink-0 tabular-nums">
                      <div className="text-xs font-extrabold text-slate-900">
                        {formatBags(parseGasNumber(bi.bags))} টি
                      </div>
                      {onDeleteGasRecord && (
                        <button
                          type="button"
                          onClick={() => void onDeleteGasRecord('Bag_Transactions', bi.rowIdx, bi.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 cursor-pointer"
                          aria-label="বস্তা এন্ট্রি মুছুন"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      )}
    </div>
  );
};
