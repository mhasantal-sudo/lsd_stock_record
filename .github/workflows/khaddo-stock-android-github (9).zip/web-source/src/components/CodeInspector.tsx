import React, { useMemo, useState } from 'react';
import { Check, Copy, FileCode2 } from 'lucide-react';
import {
  generateAndroidManifestXml,
  generateAppBuildGradleKts,
  generateGitHubActionsWorkflow,
  generateMainActivityKt,
  type AndroidAppConfig,
} from '../shared/androidConfig';

interface CodeInspectorProps {
  config: AndroidAppConfig;
}

type SourceFileKey = 'MainActivity.kt' | 'AndroidManifest.xml' | 'build.gradle.kts' | 'build-apk.yml';

export const CodeInspector: React.FC<CodeInspectorProps> = ({ config }) => {
  const [selectedFile, setSelectedFile] = useState<SourceFileKey>('MainActivity.kt');
  const [copied, setCopied] = useState(false);

  const fileMap = useMemo<Record<SourceFileKey, { path: string; content: string }>>(
    () => ({
      'MainActivity.kt': {
        path: `app/src/main/java/${config.packageName.replace(/\./g, '/')}/MainActivity.kt`,
        content: generateMainActivityKt(config),
      },
      'AndroidManifest.xml': {
        path: 'app/src/main/AndroidManifest.xml',
        content: generateAndroidManifestXml(config),
      },
      'build.gradle.kts': {
        path: 'app/build.gradle.kts',
        content: generateAppBuildGradleKts(config),
      },
      'build-apk.yml': {
        path: '.github/workflows/build-apk.yml',
        content: generateGitHubActionsWorkflow(config),
      },
    }),
    [config]
  );

  const current = fileMap[selectedFile];

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(current.content);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      // Clipboard API may be unavailable in restricted contexts
    }
  };

  return (
    <div className="rounded-xl border border-slate-200 bg-slate-950 text-slate-100 overflow-hidden">
      {/* File Tabs Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 bg-slate-900 px-3 py-2.5">
        <div className="flex flex-wrap items-center gap-1">
          {(Object.keys(fileMap) as SourceFileKey[]).map((key) => (
            <button
              key={key}
              type="button"
              onClick={() => setSelectedFile(key)}
              className={`px-2.5 py-1.5 rounded-md text-xs font-mono transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                selectedFile === key
                  ? 'bg-slate-800 text-emerald-300 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              {key}
            </button>
          ))}
        </div>

        <button
          type="button"
          onClick={handleCopy}
          className="inline-flex items-center gap-1.5 rounded-md border border-slate-700 bg-slate-800 px-2.5 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-700 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          {copied ? (
            <>
              <Check className="h-3.5 w-3.5 text-emerald-400" />
              <span>Copied</span>
            </>
          ) : (
            <>
              <Copy className="h-3.5 w-3.5" />
              <span>Copy</span>
            </>
          )}
        </button>
      </div>

      {/* File Path Subbar */}
      <div className="flex items-center gap-2 px-4 py-2 bg-slate-900/60 border-b border-slate-800/80 text-[11px] font-mono text-slate-400">
        <FileCode2 className="h-3.5 w-3.5 text-slate-500 shrink-0" />
        <span className="truncate">{current.path}</span>
      </div>

      {/* Source Viewport */}
      <div className="max-h-[480px] overflow-auto p-4 font-mono text-xs leading-relaxed text-slate-200">
        <pre className="whitespace-pre">
          <code>{current.content}</code>
        </pre>
      </div>
    </div>
  );
};
