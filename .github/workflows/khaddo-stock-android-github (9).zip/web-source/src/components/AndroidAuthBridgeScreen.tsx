import React, { useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  CheckCircle2,
  Loader2,
  ShieldCheck,
  Smartphone,
} from 'lucide-react';
import {
  GOOGLE_AUTH_PROJECT_ID,
  googleSignIn,
  submitAndroidAuthHandoff,
} from '../shared/googleAuth';

interface AndroidAuthBridgeScreenProps {
  authState: string;
}

export const AndroidAuthBridgeScreen: React.FC<AndroidAuthBridgeScreenProps> = ({
  authState,
}) => {
  const [status, setStatus] = useState<'idle' | 'signing_in' | 'success' | 'error'>('idle');
  const [signedInEmail, setSignedInEmail] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const [callbackUrl, setCallbackUrl] = useState(
    `khaddostock://auth-callback?state=${encodeURIComponent(authState)}`
  );

  const handleStartGoogleLogin = async () => {
    setStatus('signing_in');
    setErrorMsg(null);
    try {
      const { user, accessToken } = await googleSignIn();
      try {
        await submitAndroidAuthHandoff(authState, user, accessToken);
      } catch {
        // Deep-link below directly delivers the token to the APK even without server relay
      }
      const params = new URLSearchParams({
        state: authState,
        access_token: accessToken,
      });
      if (user.email) params.set('email', user.email);
      if (user.displayName) params.set('display_name', user.displayName);
      if (user.uid) params.set('uid', user.uid);
      if (user.photoURL) params.set('photo_url', user.photoURL);
      const nextCallbackUrl = `khaddostock://auth-callback?${params.toString()}`;
      setCallbackUrl(nextCallbackUrl);
      setSignedInEmail(user.email || user.displayName || 'Google অ্যাকাউন্ট');
      setStatus('success');
      window.setTimeout(() => {
        window.location.href = nextCallbackUrl;
      }, 350);
    } catch (err) {
      setStatus('error');
      setErrorMsg(
        err instanceof Error
          ? err.message
          : 'গুগল লগইন সম্পন্ন করা যায়নি। অনুগ্রহ করে আবার চেষ্টা করুন।'
      );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-950 via-[#0D6E4E] to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md rounded-3xl bg-white shadow-2xl border border-emerald-100 overflow-hidden">
        <div className="bg-gradient-to-r from-[#0D6E4E] to-emerald-700 px-6 py-5 text-white flex items-center gap-3">
          <div className="h-11 w-11 rounded-2xl bg-white/15 border border-white/25 flex items-center justify-center shrink-0">
            <Smartphone className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-extrabold leading-snug">
              অ্যান্ড্রয়েড অ্যাপের জন্য গুগল লগইন
            </h1>
            <p className="text-xs text-emerald-100/90 mt-0.5">
              খাদ্যশস্য মজুদ ও Google Sheets নিরাপদ সংযোগ
            </p>
          </div>
        </div>

        <div className="p-6 space-y-5">
          {status === 'success' ? (
            <div className="space-y-4">
              <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4 flex items-start gap-3">
                <CheckCircle2 className="h-6 w-6 text-emerald-700 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <div className="text-sm font-extrabold text-emerald-950">
                    গুগল লগইন সফল হয়েছে!
                  </div>
                  {signedInEmail && (
                    <div className="text-xs font-semibold text-emerald-800 break-all">
                      ইমেইল: {signedInEmail}
                    </div>
                  )}
                  <p className="text-xs text-emerald-900/80 leading-relaxed">
                    আপনার অ্যান্ড্রয়েড অ্যাপে স্বয়ংক্রিয়ভাবে ফিরে যাওয়া হচ্ছে। স্বয়ংক্রিয়ভাবে না ফিরলে নিচের বাটনে চাপ দিন।
                  </p>
                </div>
              </div>

              <a
                href={callbackUrl}
                className="w-full min-h-[48px] inline-flex items-center justify-center gap-2 rounded-2xl bg-[#0D6E4E] hover:bg-emerald-900 px-5 py-3 text-sm font-extrabold text-white shadow-md transition-colors"
              >
                <ArrowLeft className="h-4 w-4" />
                <span>অ্যান্ড্রয়েড অ্যাপে ফিরে যান</span>
              </a>
            </div>
          ) : (
            <>
              <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 space-y-2">
                <div className="flex items-center gap-2 text-xs font-extrabold text-slate-900">
                  <ShieldCheck className="h-4 w-4 text-[#0D6E4E] shrink-0" />
                  <span>কেন ব্রাউজারে খোলা হয়েছে?</span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  গুগলের নিরাপত্তানীতির কারণে APK-এর ভেতরে সরাসরি জিমেইল লগইন ব্লক থাকে। এখান থেকে আপনার জিমেইল দিয়ে সাইন-ইন করলে সেশনটি নিরাপদে আপনার অ্যান্ড্রয়েড অ্যাপে যুক্ত হয়ে যাবে।
                </p>
              </div>

              {status === 'error' && errorMsg && (
                <div className="rounded-2xl border border-rose-200 bg-rose-50 p-4 space-y-2 text-xs text-rose-900">
                  <div className="flex items-start gap-2 font-bold">
                    <AlertTriangle className="h-4 w-4 text-rose-600 shrink-0 mt-0.5" />
                    <span>{errorMsg}</span>
                  </div>
                  <p className="text-[11px] text-rose-800/90 leading-relaxed">
                    <strong>অন্য শেয়ার করা Gmail-এ সমস্যা হলে:</strong> Google Cloud Console ({GOOGLE_AUTH_PROJECT_ID || 'Project'}) →{' '}
                    <strong>APIs &amp; Services → OAuth consent screen → Audience (Test users)</strong>-এ ওই ইমেইলটি যুক্ত থাকতে হবে।
                  </p>
                </div>
              )}

              <button
                type="button"
                onClick={() => void handleStartGoogleLogin()}
                disabled={status === 'signing_in'}
                className="w-full min-h-[50px] inline-flex items-center justify-center gap-3 rounded-2xl bg-[#0D6E4E] hover:bg-emerald-900 disabled:opacity-60 px-5 py-3.5 text-sm font-extrabold text-white shadow-lg transition-colors cursor-pointer"
              >
                {status === 'signing_in' ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin" />
                    <span>গুগল লগইন চলছে...</span>
                  </>
                ) : (
                  <>
                    <svg className="h-5 w-5 bg-white rounded-full p-0.5" viewBox="0 0 48 48">
                      <path
                        fill="#EA4335"
                        d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                      />
                      <path
                        fill="#4285F4"
                        d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                      />
                      <path
                        fill="#FBBC05"
                        d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                      />
                      <path
                        fill="#34A853"
                        d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                      />
                    </svg>
                    <span>গুগল অ্যাকাউন্ট দিয়ে সাইন-ইন করুন</span>
                  </>
                )}
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
