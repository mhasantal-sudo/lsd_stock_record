import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  BarChart3,
  CheckCircle2,
  ClipboardList,
  FileCheck2,
  FileText,
  Home,
  Minus,
  Plus,
  RefreshCw,
  Settings,
  Warehouse,
} from 'lucide-react';
import { AndroidAuthBridgeScreen } from './components/AndroidAuthBridgeScreen';
import { BatchEntryModal } from './components/BatchEntryModal';
import { DistributionDoModal } from './components/DistributionDoModal';
import { FortnightlyReportView } from './components/FortnightlyReportView';
import {
  ProductIcon,
  formatBags,
  formatMetricTons,
  toBanglaDigits,
} from './components/GrainIcons';
import { LedgerView, type LedgerSubTab } from './components/LedgerView';
import { OfflineIndicator } from './components/OfflineIndicator';
import { PWAInstallButton } from './components/PWAInstallButton';
import { SettingsView } from './components/SettingsView';
import { SheetWriteConfirmModal } from './components/SheetWriteConfirmModal';
import { StockInventoryView } from './components/StockInventoryView';
import {
  useGrainStore,
  type BatchInputPayload,
  type DoDistributionPayload,
} from './store/useGrainStore';
import { itemNameBnToProduct, parseGasNumber } from './shared/gasBridge';
import {
  DEFAULT_MAIN_APPS_SCRIPT_URL,
  PRODUCTS,
  PRODUCT_MAP,
  type ChannelMode,
  type ProductCategory,
} from './types/grain';

type MainTab = 'home' | 'stock' | 'ledger' | 'report' | 'settings';

export default function App() {
  if (typeof window !== 'undefined') {
    const params = new URLSearchParams(window.location.search);
    const androidAuth = params.get('android_auth');
    const authState = params.get('state') || '';
    if (androidAuth === '1' && authState.length >= 16) {
      return <AndroidAuthBridgeScreen authState={authState} />;
    }
  }
  return <MainApp />;
}

function MainApp() {
  const store = useGrainStore();

  const [activeTab, setActiveTab] = useState<MainTab>('home');
  const [ledgerSubTab, setLedgerSubTab] = useState<LedgerSubTab>('ledger');
  const [settingsPreset, setSettingsPreset] = useState<{
    product: ProductCategory;
    mode: ChannelMode;
  }>({ product: 'rice', mode: 'distribution' });

  const [receiptModal, setReceiptModal] = useState<{
    open: boolean;
    product: ProductCategory;
    godown?: string;
    khamal?: string;
  }>({
    open: false,
    product: 'rice',
  });

  const [distModal, setDistModal] = useState<{
    open: boolean;
    product: ProductCategory;
    godown?: string;
    khamal?: string;
    modalMode?: 'existing' | 'distributed' | 'new' | 'dispatch' | 'shortage' | 'empty_bag';
  }>({
    open: false,
    product: 'rice',
  });

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(toBanglaDigits(msg));
    window.setTimeout(() => {
      setToastMessage((prev) => (prev === toBanglaDigits(msg) ? null : prev));
    }, 3600);
  };

  const openReceipt = (product: ProductCategory = 'rice', godown?: string, khamal?: string) => {
    setDistModal((prev) => ({ ...prev, open: false }));
    setReceiptModal({ open: true, product, godown, khamal });
  };

  const openDistribution = (
    product: ProductCategory = 'rice',
    godown?: string,
    khamal?: string,
    modalMode?: 'existing' | 'distributed' | 'new' | 'dispatch' | 'shortage' | 'empty_bag'
  ) => {
    setReceiptModal((prev) => ({ ...prev, open: false }));
    setDistModal({ open: true, product, godown, khamal, modalMode });
  };

  const handleSaveBatch = async (payload: BatchInputPayload & { uniqueId?: string }) => {
    const res = await store.submitGasReceiptBatch(payload);
    if (res.ok) {
      const pName = PRODUCT_MAP[payload.product].nameBn;
      showToast(res.message || `${res.count || 1}টি খামালের ${pName} প্রাপ্তি সংরক্ষিত হয়েছে।`);
    }
    return res;
  };

  const handleExecuteDoDistribution = async (payload: DoDistributionPayload) => {
    const res = await store.executeDoDistributionAsync(payload);
    if (res.ok) {
      showToast(
        res.message ||
          `${res.doCount || 1}টি ডিও (${res.khamalCount}টি খামাল) বিতরণ ও শর্টেজ সংরক্ষিত হয়েছে।`
      );
    }
    return res;
  };

  const handleSubmitDispatch: typeof store.submitGasDispatch = async (input) => {
    const res = await store.submitGasDispatch(input);
    if (res.ok && res.message) {
      showToast(res.message);
    }
    return res;
  };

  const handleSubmitEmptyBagIssue: typeof store.submitGasEmptyBagIssue = async (input) => {
    const res = await store.submitGasEmptyBagIssue(input);
    if (res.ok && res.message) {
      showToast(res.message);
    }
    return res;
  };

  const handleSubmitDiscrepancy: typeof store.submitGasDiscrepancy = async (input) => {
    const res = await store.submitGasDiscrepancy(input);
    if (res.ok && res.message) {
      showToast(res.message);
    }
    return res;
  };

  const handleOpenChannelSettings = (product: ProductCategory, mode: ChannelMode) => {
    setReceiptModal((prev) => ({ ...prev, open: false }));
    setDistModal((prev) => ({ ...prev, open: false }));
    setSettingsPreset({ product, mode });
    setActiveTab('settings');
  };

  const isGasLive = store.gasBridgeStatus === 'connected' && Boolean(store.gasData);
  const gasDash = isGasLive ? store.gasData?.dashboard : undefined;
  const gasSettings = isGasLive ? store.gasData?.settings : undefined;

  const grandTotals = useMemo(() => {
    const grainProducts: ProductCategory[] = ['paddy', 'rice', 'wheat'];
    let initMt = 0;
    let initBags = 0;
    let distMt = 0;
    let distBags = 0;
    let shortMt = 0;
    let shortBags = 0;
    let curMt = 0;
    let curBags = 0;
    let activeKhamals = 0;

    if (gasDash) {
      initMt = parseGasNumber(gasDash.totalInitialWeight);
      initBags = Math.round(parseGasNumber(gasDash.totalInitialBags));
      distMt = parseGasNumber(gasDash.totalGrainIssuedWeight);
      distBags = Math.round(parseGasNumber(gasDash.totalGrainIssuedBags));
      shortMt = parseGasNumber(gasDash.totalDiscrepancyWeight);
      shortBags = Math.round(parseGasNumber(gasDash.totalDiscrepancyBags));
      curMt = parseGasNumber(gasDash.balanceWeight);
      curBags = Math.round(parseGasNumber(gasDash.balanceBags));
    } else {
      grainProducts.forEach((p) => {
        const s = store.productTotals[p];
        initMt += s.receiptMt;
        initBags += s.receiptBags;
        distMt += s.distMt;
        distBags += s.distBags;
        shortMt += s.shortageMt;
        shortBags += s.shortageBags;
        curMt += s.currentMt;
        curBags += s.currentBags;
      });
    }

    const activeGodownSet = new Set<string>();
    store.khamalStocks.forEach((k) => {
      if (k.currentBags > 0 || k.currentMt > 0) {
        activeKhamals += 1;
        activeGodownSet.add(k.godownNo);
      }
    });

    return {
      initMt,
      initBags,
      distMt,
      distBags,
      shortMt,
      shortBags,
      curMt,
      curBags,
      activeKhamals,
      activeGodowns: activeGodownSet.size,
    };
  }, [gasDash, store.khamalStocks, store.productTotals]);

  const khathRows = useMemo(() => {
    if (gasDash?.khathSummary) {
      return Object.entries(gasDash.khathSummary)
        .map(([khath, v]) => ({
          khath,
          bags: Math.round(parseGasNumber(v.deliveredBags)),
          weight: parseGasNumber(v.deliveredWeight),
        }))
        .sort((a, b) => b.weight - a.weight);
    }

    const map = new Map<string, { khath: string; bags: number; weight: number }>();
    store.transactions
      .filter((tx) => tx.type === 'distribution' && !PRODUCT_MAP[tx.product].isBagProduct)
      .forEach((tx) => {
        const key = tx.channel || 'অন্যান্য';
        const cur = map.get(key) || { khath: key, bags: 0, weight: 0 };
        cur.bags += tx.bags;
        cur.weight = Number((cur.weight + tx.metricTons).toFixed(4));
        map.set(key, cur);
      });
    return Array.from(map.values()).sort((a, b) => b.weight - a.weight);
  }, [gasDash, store.transactions]);

  const pendingDos = store.pendingDos;
  const distributedDos = store.distributedDos;

  const recentActivity = useMemo(() => {
    if (isGasLive && store.gasData) {
      const items: Array<{
        id: string;
        type: 'receipt' | 'distribution' | 'shortage';
        product: ProductCategory;
        title: string;
        subtitle: string;
        bags: number;
        mt: number;
      }> = [];

      (store.gasData.issueList || []).slice(-5).forEach((r, idx) => {
        items.push({
          id: `g-iss-${r.id}-${idx}`,
          type: 'distribution',
          product: 'rice',
          title: `খামাল ${r.khamalId}`,
          subtitle: `বিতরণ · ${r.khath} · ডিও: ${r.doNo}`,
          bags: Math.round(parseGasNumber(r.bags)),
          mt: parseGasNumber(r.weight),
        });
      });

      (store.gasData.masterGrain || []).slice(-4).forEach((m, idx) => {
        items.push({
          id: `g-mg-${m.khamalId}-${idx}`,
          type: 'receipt',
          product: itemNameBnToProduct(m.item),
          title: `${m.godown} / খামাল ${m.khamalId}`,
          subtitle: `প্রাপ্তি · ${m.category || 'মজুদ'}`,
          bags: Math.round(parseGasNumber(m.initBags)),
          mt: parseGasNumber(m.initWeight),
        });
      });

      return items.slice(0, 8);
    }

    return store.transactions.slice(0, 8).map((tx) => ({
      id: tx.id,
      type: tx.type,
      product: tx.product,
      title: `${tx.godownNo} / ${tx.khamalNo}`,
      subtitle: `${tx.type === 'receipt' ? 'প্রাপ্তি' : tx.type === 'shortage' ? 'শর্টেজ' : 'বিতরণ'} · ${tx.channel}${tx.doNumber ? ` · ডিও: ${tx.doNumber}` : ''}`,
      bags: tx.bags,
      mt: tx.metricTons,
    }));
  }, [isGasLive, store.gasData, store.transactions]);

  const grainComposition = useMemo(() => {
    const paddyMt = Math.max(0, store.productTotals.paddy.currentMt);
    const riceMt = Math.max(0, store.productTotals.rice.currentMt);
    const wheatMt = Math.max(0, store.productTotals.wheat.currentMt);
    const total = paddyMt + riceMt + wheatMt;
    const distRate =
      grandTotals.initMt > 0
        ? Math.min(100, Math.round((grandTotals.distMt / grandTotals.initMt) * 100))
        : 0;
    return {
      total,
      distRate,
      paddyPct: total > 0 ? Math.round((paddyMt / total) * 100) : 0,
      ricePct: total > 0 ? Math.round((riceMt / total) * 100) : 0,
      wheatPct: total > 0 ? Math.round((wheatMt / total) * 100) : 0,
      paddyMt,
      riceMt,
      wheatMt,
    };
  }, [store.productTotals, grandTotals.initMt, grandTotals.distMt]);

  const totalKhathWeight = useMemo(
    () => khathRows.reduce((acc, r) => acc + r.weight, 0),
    [khathRows]
  );

  const bosta50Stats = store.productTotals.bosta_50;
  const bosta30Stats = store.productTotals.bosta_30;
  const headerBrandTitle = gasSettings?.lsdName
    ? `${gasSettings.lsdName}`
    : 'খাদ্যশস্য মজুদ';

  const mainWebAppUrl =
    store.externalSyncConfig.externalAppUrl?.trim() || DEFAULT_MAIN_APPS_SCRIPT_URL;

  return (
    <div className="min-h-screen bg-[#F3F7F5] text-slate-900 flex flex-col pb-20 md:pb-8">
      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-30 border-b border-emerald-900/10 bg-white/95 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-14 sm:h-16 flex items-center justify-between gap-2 sm:gap-4">
          <div className="flex items-center gap-2 min-w-0">
            <a
              href="#home"
              onClick={(e) => {
                e.preventDefault();
                setActiveTab('home');
              }}
              className="text-sm sm:text-lg font-bold tracking-tight text-[#064E3B] truncate whitespace-nowrap"
            >
              {headerBrandTitle}
            </a>

            {gasSettings?.fiscalYears && gasSettings.fiscalYears.length > 0 && (
              <select
                aria-label="অর্থবছর নির্বাচন"
                value={store.selectedFY || gasSettings.activeFY || 'ALL'}
                onChange={(e) => void store.changeFiscalYear(e.target.value)}
                className="h-8 rounded-lg border border-emerald-200 bg-emerald-50/70 px-2 text-[11px] font-bold text-emerald-950 focus:border-emerald-700 focus:outline-none shrink-0"
              >
                {gasSettings.fiscalYears.map((fy) => (
                  <option key={fy.name} value={fy.name}>
                    {toBanglaDigits(fy.name)}
                  </option>
                ))}
                <option value="ALL">সকল অর্থবছর</option>
              </select>
            )}
          </div>

          <nav className="hidden md:flex items-center gap-6 text-sm font-semibold text-slate-600">
            {(
              [
                { id: 'home', label: 'হোম' },
                { id: 'stock', label: 'মজুদ তালিকা' },
                { id: 'ledger', label: 'চ্যানেল ও ডিও রেকর্ড' },
                { id: 'report', label: 'পাক্ষিক প্রতিবেদন' },
                { id: 'settings', label: 'সেটিংস' },
              ] as Array<{ id: MainTab; label: string }>
            ).map((nav) => (
              <button
                key={nav.id}
                type="button"
                onClick={() => {
                  if (nav.id === 'ledger') setLedgerSubTab('ledger');
                  setActiveTab(nav.id);
                }}
                className={`py-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  activeTab === nav.id
                    ? 'text-slate-950 underline decoration-[#0D6E4E] decoration-2 underline-offset-8'
                    : 'hover:text-slate-900'
                }`}
              >
                {nav.label}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
            <PWAInstallButton />
            <button
              type="button"
              onClick={() => openReceipt('rice')}
              className="inline-flex items-center gap-1 sm:gap-1.5 rounded-xl bg-[#0D6E4E] hover:bg-emerald-900 px-2.5 sm:px-3.5 py-2 text-xs font-bold text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Plus className="h-3.5 w-3.5 stroke-[2.5]" />
              <span>প্রাপ্তি</span>
            </button>
            <button
              type="button"
              onClick={() => openDistribution('rice')}
              className="inline-flex items-center gap-1 sm:gap-1.5 rounded-xl bg-[#B91C1C] hover:bg-red-800 px-2.5 sm:px-3.5 py-2 text-xs font-bold text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Minus className="h-3.5 w-3.5 stroke-[2.5]" />
              <span>বিতরণ</span>
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-5 sm:py-7 space-y-6">
        {toastMessage && (
          <div
            role="status"
            className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-xs sm:text-sm font-semibold text-emerald-900 flex items-center gap-2.5 shadow-xs"
          >
            <CheckCircle2 className="h-4 w-4 text-emerald-700 shrink-0" />
            <span>{toastMessage}</span>
          </div>
        )}

        {store.gasBridgeStatus === 'error' && activeTab === 'home' && (
          <div className="rounded-2xl border border-rose-200 bg-rose-50/90 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="space-y-0.5 min-w-0">
              <div className="text-xs sm:text-sm font-bold text-rose-950">
                গুগল শিট বা ওয়েব অ্যাপ থেকে ডেটা লোড করা যায়নি
              </div>
              <p className="text-xs text-rose-900/85">
                {store.gasBridgeMessage || 'সেটিংস থেকে গুগল লগইন অথবা ওয়েব অ্যাপ সংযোগ পরীক্ষা করুন।'}
              </p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => void store.syncExternalDos()}
                className="min-h-[38px] inline-flex items-center gap-1.5 rounded-xl bg-rose-800 hover:bg-rose-900 px-3 py-1.5 text-xs font-bold text-white cursor-pointer"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                <span>পুনরায় চেষ্টা</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('settings')}
                className="min-h-[38px] inline-flex items-center gap-1.5 rounded-xl border border-rose-300 bg-white hover:bg-rose-100 px-3 py-1.5 text-xs font-bold text-rose-950 cursor-pointer"
              >
                <Settings className="h-3.5 w-3.5" />
                <span>সেটিংস</span>
              </button>
            </div>
          </div>
        )}

        {/* VIEW 1: HOME */}
        {activeTab === 'home' && (
          <div className="space-y-6">
            {/* Hero Executive Colorful Command Banner */}
            <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#064E3B] via-[#0B6E4F] to-[#0E7490] text-white p-5 sm:p-7 shadow-lg shadow-emerald-950/10 space-y-5">
              {/* Subtle geometric decorative ambient highlights (no blur blobs) */}
              <div
                aria-hidden="true"
                className="pointer-events-none absolute -top-24 -right-24 h-64 w-64 rounded-full bg-gradient-to-br from-amber-300/20 to-teal-200/5"
              />
              <div
                aria-hidden="true"
                className="pointer-events-none absolute -bottom-24 -left-16 h-56 w-56 rounded-full bg-gradient-to-tr from-emerald-300/15 to-cyan-300/5"
              />

              <div className="relative flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <h1 className="text-xl sm:text-3xl font-bold tracking-tight text-white text-balance">
                    {gasSettings?.lsdName
                      ? `${gasSettings.lsdName} — সরকারি খাদ্যশস্য মজুদ`
                      : 'সরকারি খাদ্যশস্যের মজুদ ও ডিও বিতরণ ব্যবস্থাপনা'}
                  </h1>
                  <p className="text-xs sm:text-sm text-emerald-100/90 leading-relaxed">
                    {gasSettings
                      ? `${[gasSettings.upazila, gasSettings.district].filter(Boolean).join(', ')} · অর্থবছর: ${toBanglaDigits(store.gasData?.fy?.name || gasSettings.activeFY || 'সক্রিয়')} · ${toBanglaDigits(grandTotals.activeKhamals)}টি সক্রিয় খামাল (${toBanglaDigits(grandTotals.activeGodowns)}টি গুদাম)`
                      : `গুদাম ও খামালভিত্তিক ধান, চাল, গম, ৫০ ও ৩০ কেজি খালি বস্তা ও শর্টেজ হিসাব · ${toBanglaDigits(grandTotals.activeKhamals)}টি সক্রিয় খামাল (${toBanglaDigits(grandTotals.activeGodowns)}টি গুদাম)`}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => void store.manualRefreshData()}
                  disabled={store.isSyncingDos || store.isGoogleSigningIn}
                  className="min-h-[40px] inline-flex items-center gap-1.5 rounded-xl border border-white/25 bg-white/15 hover:bg-white/25 px-4 py-2 text-xs font-bold text-white backdrop-blur-xs transition-colors self-start shrink-0 whitespace-nowrap cursor-pointer"
                >
                  <RefreshCw className={`h-3.5 w-3.5 ${store.isSyncingDos || store.isGoogleSigningIn ? 'animate-spin' : ''}`} />
                  <span>{store.isSyncingDos || store.isGoogleSigningIn ? 'আপডেট হচ্ছে...' : 'তথ্য হালনাগাদ'}</span>
                </button>
              </div>

              {/* 4 Vibrant Colorful KPI Cards */}
              <div className="relative grid grid-cols-2 lg:grid-cols-4 gap-3.5 tabular-nums">
                <div className="rounded-2xl bg-gradient-to-br from-sky-400/20 to-indigo-500/25 border border-sky-200/30 p-4 backdrop-blur-xs">
                  <div className="text-xs font-semibold text-sky-100">প্রারম্ভিক ও মোট প্রাপ্তি</div>
                  <div className="text-xl sm:text-2xl font-bold text-white mt-1">
                    {formatMetricTons(grandTotals.initMt)}{' '}
                    <span className="text-xs font-medium text-sky-100/90">মে.টন</span>
                  </div>
                  <div className="text-xs text-sky-100/85 mt-1">
                    {formatBags(grandTotals.initBags)} বস্তা
                  </div>
                </div>

                <div className="rounded-2xl bg-gradient-to-br from-rose-500/30 to-orange-500/25 border border-rose-200/35 p-4 backdrop-blur-xs">
                  <div className="text-xs font-semibold text-rose-100">মোট বিতরণ</div>
                  <div className="text-xl sm:text-2xl font-bold text-white mt-1">
                    {formatMetricTons(grandTotals.distMt)}{' '}
                    <span className="text-xs font-medium text-rose-100/90">মে.টন</span>
                  </div>
                  <div className="text-xs text-rose-100/85 mt-1">
                    {formatBags(grandTotals.distBags)} বস্তা · হার {toBanglaDigits(grainComposition.distRate)}%
                  </div>
                </div>

                <div className="rounded-2xl bg-gradient-to-br from-amber-400/25 to-yellow-500/20 border border-amber-200/35 p-4 backdrop-blur-xs">
                  <div className="text-xs font-semibold text-amber-100">ঘাটতি / শর্টেজ</div>
                  <div className="text-xl sm:text-2xl font-bold text-white mt-1">
                    {formatMetricTons(grandTotals.shortMt)}{' '}
                    <span className="text-xs font-medium text-amber-100/90">মে.টন</span>
                  </div>
                  <div className="text-xs text-amber-100/85 mt-1">
                    {formatBags(grandTotals.shortBags)} বস্তা
                  </div>
                </div>

                {/* Primary Focal KPI Anchor */}
                <div className="rounded-2xl bg-white text-slate-900 p-4 shadow-md border border-emerald-100">
                  <div className="text-xs font-bold text-emerald-800">বর্তমান নিট অবশিষ্ট</div>
                  <div className="text-xl sm:text-2xl font-bold text-[#065F46] mt-1">
                    {formatMetricTons(grandTotals.curMt)}{' '}
                    <span className="text-xs font-semibold text-emerald-700">মে.টন</span>
                  </div>
                  <div className="text-xs font-semibold text-slate-600 mt-1">
                    {formatBags(grandTotals.curBags)} বস্তা
                  </div>
                </div>
              </div>

              {/* Colorful Multi-Segment Live Grain Composition Strip */}
              <div className="relative rounded-2xl bg-black/15 border border-white/15 px-4 py-3 space-y-2 tabular-nums">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                  <span className="font-bold text-emerald-50">
                    শস্যের তুলনামূলক মজুদ অনুপাত
                  </span>
                  <div className="flex flex-wrap items-center gap-3 text-[11px] font-semibold text-white/90">
                    <span>ধান {toBanglaDigits(grainComposition.paddyPct)}%</span>
                    <span aria-hidden="true">·</span>
                    <span>চাল {toBanglaDigits(grainComposition.ricePct)}%</span>
                    <span aria-hidden="true">·</span>
                    <span>গম {toBanglaDigits(grainComposition.wheatPct)}%</span>
                  </div>
                </div>
                <div className="h-2.5 w-full rounded-full bg-white/15 overflow-hidden flex">
                  {grainComposition.total > 0 ? (
                    <>
                      <div
                        className="h-full bg-gradient-to-r from-amber-400 to-yellow-300 transition-all duration-300"
                        style={{ width: `${(grainComposition.paddyMt / grainComposition.total) * 100}%` }}
                        title={`ধান: ${formatMetricTons(grainComposition.paddyMt)} মে.টন`}
                      />
                      <div
                        className="h-full bg-gradient-to-r from-emerald-300 to-teal-300 transition-all duration-300"
                        style={{ width: `${(grainComposition.riceMt / grainComposition.total) * 100}%` }}
                        title={`চাল: ${formatMetricTons(grainComposition.riceMt)} মে.টন`}
                      />
                      <div
                        className="h-full bg-gradient-to-r from-orange-400 to-rose-400 transition-all duration-300"
                        style={{ width: `${(grainComposition.wheatMt / grainComposition.total) * 100}%` }}
                        title={`গম: ${formatMetricTons(grainComposition.wheatMt)} মে.টন`}
                      />
                    </>
                  ) : (
                    <div className="h-full w-full bg-white/10" />
                  )}
                </div>
              </div>
            </section>

            {/* Product Categories as Colorful Jewel-Toned Cards */}
            <section className="space-y-3.5">
              <div className="flex items-center justify-between gap-2">
                <h2 className="text-base sm:text-lg font-bold text-slate-900">
                  পণ্যভিত্তিক মজুদ ও দ্রুত এন্ট্রি
                </h2>
                <button
                  type="button"
                  onClick={() => setActiveTab('stock')}
                  className="text-xs font-bold text-[#0D6E4E] hover:text-emerald-950 flex items-center gap-1 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <span>সকল খামাল দেখুন</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {PRODUCTS.slice(0, 3).map((item) => {
                  const stats = store.productTotals[item.id];
                  const palette =
                    item.id === 'paddy'
                      ? {
                          topBar: 'from-amber-500 via-yellow-500 to-orange-500',
                          iconBg: 'bg-gradient-to-br from-amber-500 to-orange-500 text-white shadow-sm shadow-amber-500/25',
                          cardBg: 'border-amber-200/90 bg-white',
                          statBg: 'bg-amber-50/70 border-amber-200/70',
                          valueText: 'text-amber-950',
                        }
                      : item.id === 'rice'
                        ? {
                            topBar: 'from-emerald-600 via-teal-500 to-green-500',
                            iconBg: 'bg-gradient-to-br from-emerald-600 to-teal-600 text-white shadow-sm shadow-emerald-600/25',
                            cardBg: 'border-emerald-200/90 bg-white',
                            statBg: 'bg-emerald-50/70 border-emerald-200/70',
                            valueText: 'text-emerald-950',
                          }
                        : {
                            topBar: 'from-orange-600 via-amber-600 to-rose-500',
                            iconBg: 'bg-gradient-to-br from-orange-600 to-rose-500 text-white shadow-sm shadow-orange-600/25',
                            cardBg: 'border-orange-200/90 bg-white',
                            statBg: 'bg-orange-50/70 border-orange-200/70',
                            valueText: 'text-orange-950',
                          };

                  return (
                    <div
                      key={item.id}
                      className={`overflow-hidden rounded-2xl border ${palette.cardBg} flex flex-col justify-between transition-transform duration-200 hover:-translate-y-0.5`}
                    >
                      <div className={`h-1.5 w-full bg-gradient-to-r ${palette.topBar}`} />
                      <div className="p-4 flex-1 flex flex-col justify-between gap-4">
                        <div className="flex items-center gap-3 min-w-0">
                          <div
                            className={`h-12 w-12 rounded-2xl ${palette.iconBg} flex items-center justify-center shrink-0`}
                          >
                            <ProductIcon product={item.id} className="h-7 w-7" />
                          </div>
                          <div className="min-w-0">
                            <div className="text-base font-bold text-slate-900">
                              {item.nameBn}
                            </div>
                            <div className="text-xs text-slate-500 truncate">
                              {toBanglaDigits(stats.activeKhamals)}টি সক্রিয় খামাল
                            </div>
                          </div>
                        </div>

                        <div className={`rounded-xl border ${palette.statBg} p-3 tabular-nums`}>
                          <div className={`text-xl font-bold ${palette.valueText}`}>
                            {formatMetricTons(stats.currentMt)}{' '}
                            <span className="text-xs font-semibold text-slate-600">মে.টন</span>
                          </div>
                          <div className="text-xs font-semibold text-slate-600 mt-0.5">
                            {formatBags(stats.currentBags)} বস্তা
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-2">
                          <button
                            type="button"
                            onClick={() => openReceipt(item.id)}
                            className="min-h-[40px] rounded-xl bg-gradient-to-r from-[#0D6E4E] to-teal-700 hover:from-emerald-800 hover:to-teal-800 px-3 py-2 text-xs font-bold text-white flex items-center justify-center gap-1 whitespace-nowrap cursor-pointer shadow-xs"
                          >
                            <Plus className="h-3.5 w-3.5 stroke-[2.5]" />
                            <span>খামাল যুক্ত</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => openDistribution(item.id)}
                            className="min-h-[40px] rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-700 hover:to-red-700 px-3 py-2 text-xs font-bold text-white flex items-center justify-center gap-1 whitespace-nowrap cursor-pointer shadow-xs"
                          >
                            <Minus className="h-3.5 w-3.5 stroke-[2.5]" />
                            <span>বিতরণ করুন</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}

                {/* 4th Card: খালি বস্তা (৫০ কেজি + ৩০ কেজি দুই ধরন) */}
                <div className="overflow-hidden rounded-2xl border border-indigo-200/90 bg-white flex flex-col justify-between transition-transform duration-200 hover:-translate-y-0.5">
                  <div className="h-1.5 w-full bg-gradient-to-r from-indigo-600 via-blue-500 to-cyan-500" />
                  <div className="p-4 flex-1 flex flex-col justify-between gap-3.5">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="h-12 w-12 rounded-2xl bg-gradient-to-br from-indigo-600 to-blue-600 text-white shadow-sm shadow-indigo-600/25 flex items-center justify-center shrink-0">
                        <ProductIcon product="bosta" className="h-7 w-7" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-base font-bold text-slate-900">খালি বস্তা</div>
                        <div className="text-xs text-slate-500 truncate">
                          ৫০ কেজি ও ৩০ কেজি বস্তা
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2.5 tabular-nums">
                      <div className="rounded-xl bg-indigo-50/70 border border-indigo-200/70 p-2.5">
                        <div className="text-[11px] font-bold text-indigo-900">৫০ কেজি বস্তা</div>
                        <div className="text-base font-bold text-slate-900 mt-0.5">
                          {formatBags(bosta50Stats.currentBags)}
                        </div>
                        <div className="mt-2 flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => openReceipt('bosta_50')}
                            className="flex-1 min-h-[32px] py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold cursor-pointer"
                          >
                            + যুক্ত
                          </button>
                          <button
                            type="button"
                            onClick={() => openDistribution('bosta_50')}
                            className="flex-1 min-h-[32px] py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-[11px] font-bold cursor-pointer"
                          >
                            - বাদ
                          </button>
                        </div>
                      </div>

                      <div className="rounded-xl bg-cyan-50/70 border border-cyan-200/80 p-2.5">
                        <div className="text-[11px] font-bold text-cyan-900">৩০ কেজি বস্তা</div>
                        <div className="text-base font-bold text-slate-900 mt-0.5">
                          {formatBags(bosta30Stats.currentBags)}
                        </div>
                        <div className="mt-2 flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => openReceipt('bosta_30')}
                            className="flex-1 min-h-[32px] py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold cursor-pointer"
                          >
                            + যুক্ত
                          </button>
                          <button
                            type="button"
                            onClick={() => openDistribution('bosta_30')}
                            className="flex-1 min-h-[32px] py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-[11px] font-bold cursor-pointer"
                          >
                            - বাদ
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Pending DOs Quick Dispatch Strip & Distributed DO Shortcut */}
            <section className="overflow-hidden rounded-2xl border border-rose-200/80 bg-white">
              <div className="h-1 w-full bg-gradient-to-r from-rose-600 via-red-500 to-amber-500" />
              <div className="p-4 sm:p-5 space-y-3.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-rose-600 to-red-600 text-white flex items-center justify-center shrink-0">
                      <FileText className="h-4 w-4" />
                    </div>
                    <h2 className="text-sm sm:text-base font-bold text-slate-900">
                      পেন্ডিং ডিও নম্বর ({toBanglaDigits(pendingDos.length)}টি)
                    </h2>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setLedgerSubTab('distributed_dos');
                        setActiveTab('ledger');
                      }}
                      className="min-h-[36px] inline-flex items-center gap-1.5 rounded-xl border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 px-3 py-1.5 text-xs font-bold text-emerald-900 whitespace-nowrap cursor-pointer"
                    >
                      <CheckCircle2 className="h-3.5 w-3.5 text-emerald-700" />
                      <span>বিতরণকৃত ডিও ({toBanglaDigits(distributedDos.length)})</span>
                    </button>

                    {pendingDos.length > 0 && (
                      <button
                        type="button"
                        onClick={() => openDistribution(pendingDos[0].product)}
                        className="min-h-[36px] rounded-xl bg-[#B91C1C] hover:bg-red-800 px-3 py-1.5 text-xs font-bold text-white whitespace-nowrap cursor-pointer"
                      >
                        ডিও বিতরণ শুরু করুন →
                      </button>
                    )}
                  </div>
                </div>

                {pendingDos.length === 0 ? (
                  <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-4 text-center text-xs text-slate-500">
                    বর্তমানে কোনো পেন্ডিং ডিও নেই। অন্য ওয়েব অ্যাপে ডিও এন্ট্রি হলে এখানে পেন্ডিং তালিকায় চলে আসবে।
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {pendingDos.slice(0, 6).map((d) => {
                      const meta = PRODUCT_MAP[d.product];
                      const remMt = Math.max(0, Number((d.totalMt - d.deliveredMt).toFixed(4)));
                      const remBags = Math.max(0, d.totalBags - d.deliveredBags);
                      return (
                        <button
                          key={d.id}
                          type="button"
                          onClick={() => openDistribution(d.product)}
                          className="text-left rounded-xl border border-rose-200/80 hover:border-rose-400 bg-gradient-to-br from-rose-50/50 to-amber-50/30 hover:from-rose-50 hover:to-amber-50/60 p-3.5 flex items-center justify-between gap-3 transition-colors cursor-pointer"
                        >
                          <div className="min-w-0">
                            <div className="text-sm font-bold text-slate-900 truncate tabular-nums">
                              ডিও: {toBanglaDigits(d.doNumber)}
                            </div>
                            <div className="text-xs text-slate-600 truncate">
                              {meta.shortBn} · {toBanglaDigits(d.category)}
                            </div>
                          </div>
                          <div className="text-right shrink-0 tabular-nums">
                            <div className="text-xs font-bold text-[#B91C1C]">
                              {meta.tracksWeight
                                ? `${formatMetricTons(remMt)} মে.টন`
                                : `${formatBags(remBags)} বস্তা`}
                            </div>
                            <div className="text-[11px] text-slate-500">বাকি প্রাপ্য</div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            </section>

            {/* Khath Summary with Colorful Jewel Progress Bars */}
            {khathRows.length > 0 && (
              <section className="overflow-hidden rounded-2xl border border-teal-200/80 bg-white">
                <div className="h-1 w-full bg-gradient-to-r from-teal-500 via-emerald-500 to-indigo-500" />
                <div className="p-4 sm:p-5 space-y-3.5">
                  <div className="flex items-center gap-2.5">
                    <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-teal-600 to-emerald-600 text-white flex items-center justify-center shrink-0">
                      <BarChart3 className="h-4 w-4" />
                    </div>
                    <h2 className="text-sm sm:text-base font-bold text-slate-900">
                      খাতভিত্তিক বিতরণ সারসংক্ষেপ
                    </h2>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 tabular-nums">
                    {khathRows.map((row, idx) => {
                      const barColors = [
                        'from-emerald-500 to-teal-500',
                        'from-indigo-500 to-blue-500',
                        'from-amber-500 to-orange-500',
                        'from-rose-500 to-pink-500',
                        'from-cyan-500 to-sky-500',
                        'from-violet-500 to-purple-500',
                      ];
                      const sharePct =
                        totalKhathWeight > 0
                          ? Math.max(4, Math.round((row.weight / totalKhathWeight) * 100))
                          : 0;
                      const barGrad = barColors[idx % barColors.length];
                      return (
                        <div
                          key={row.khath}
                          className="rounded-xl border border-slate-200/90 bg-slate-50/70 p-3.5 space-y-2"
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-xs font-bold text-slate-800 truncate">
                              {toBanglaDigits(row.khath)}
                            </span>
                            <span className="text-[11px] font-bold text-slate-500 shrink-0">
                              {toBanglaDigits(sharePct)}%
                            </span>
                          </div>
                          <div>
                            <div className="text-base font-bold text-slate-900">
                              {formatMetricTons(row.weight)}{' '}
                              <span className="text-xs font-medium text-slate-500">মে.টন</span>
                            </div>
                            <div className="text-xs text-slate-600">{formatBags(row.bags)} বস্তা</div>
                          </div>
                          <div className="h-1.5 w-full rounded-full bg-slate-200/80 overflow-hidden">
                            <div
                              className={`h-full rounded-full bg-gradient-to-r ${barGrad}`}
                              style={{ width: `${Math.min(100, sharePct)}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </section>
            )}

            {/* Recent Channel, DO & Khamal Activity */}
            <section className="rounded-2xl border border-slate-200 bg-white overflow-hidden">
              <div className="px-4 sm:px-6 py-4 border-b border-slate-100 flex items-center justify-between gap-3 bg-gradient-to-r from-slate-50 to-emerald-50/40">
                <div>
                  <h2 className="text-base font-bold text-slate-900">সাম্প্রতিক প্রাপ্তি, বিতরণ ও শর্টেজ</h2>
                  <p className="text-xs text-slate-500">সর্বশেষ চ্যানেল, ডিও ও খামাল লেনদেনের তালিকা</p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setLedgerSubTab('ledger');
                    setActiveTab('ledger');
                  }}
                  className="text-xs font-bold text-[#0D6E4E] hover:underline whitespace-nowrap cursor-pointer"
                >
                  পূর্ণাঙ্গ রেকর্ড দেখুন
                </button>
              </div>

              {recentActivity.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-500">
                  এখনও কোনো লেনদেন রেকর্ড করা হয়নি। উপরের <strong>প্রাপ্তি (+)</strong> বাটনে চাপ দিয়ে শুরু করুন।
                </div>
              ) : (
                <div className="divide-y divide-slate-100">
                  {recentActivity.map((item) => {
                    const meta = PRODUCT_MAP[item.product];
                    const isRec = item.type === 'receipt';
                    const isShortage = item.type === 'shortage';

                    return (
                      <div
                        key={item.id}
                        className="px-4 sm:px-6 py-3.5 flex items-center justify-between gap-3 hover:bg-slate-50/70 transition-colors"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div
                            className={`h-10 w-10 rounded-xl flex items-center justify-center shrink-0 text-white shadow-xs ${
                              isRec
                                ? 'bg-gradient-to-br from-emerald-600 to-teal-600'
                                : isShortage
                                  ? 'bg-gradient-to-br from-amber-500 to-orange-500'
                                  : 'bg-gradient-to-br from-rose-600 to-red-600'
                            }`}
                          >
                            {isRec ? (
                              <Plus className="h-4 w-4 stroke-[2.5]" />
                            ) : isShortage ? (
                              <AlertTriangle className="h-4 w-4" />
                            ) : (
                              <Minus className="h-4 w-4 stroke-[2.5]" />
                            )}
                          </div>
                          <div className="min-w-0">
                            <div className="text-sm font-bold text-slate-900 truncate">
                              {meta.shortBn} — {toBanglaDigits(item.title)}
                            </div>
                            <div className="text-xs text-slate-500 truncate">
                              {toBanglaDigits(item.subtitle)}
                            </div>
                          </div>
                        </div>

                        <div className="text-right shrink-0 tabular-nums">
                          {meta.tracksWeight ? (
                            <>
                              <div
                                className={`text-sm font-bold ${
                                  isRec
                                    ? 'text-emerald-800'
                                    : isShortage
                                      ? 'text-amber-800'
                                      : 'text-rose-800'
                                }`}
                              >
                                {isRec ? '+' : '-'}
                                {formatMetricTons(item.mt)} মে.টন
                              </div>
                              <div className="text-xs text-slate-500">
                                {isRec ? '+' : '-'}
                                {formatBags(item.bags)} বস্তা
                              </div>
                            </>
                          ) : (
                            <div
                              className={`text-sm font-bold ${
                                isRec
                                  ? 'text-emerald-800'
                                  : isShortage
                                    ? 'text-amber-800'
                                    : 'text-rose-800'
                              }`}
                            >
                              {isRec ? '+' : '-'}
                              {formatBags(item.bags)} বস্তা
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </section>
          </div>
        )}

        {/* VIEW 2: GODOWN & KHAMAL STOCK INVENTORY */}
        {activeTab === 'stock' && (
          <StockInventoryView
            khamalStocks={store.khamalStocks}
            godownList={store.godownList}
            onQuickEntry={(mode, product, godownNo, khamalNo) => {
              if (mode === 'receipt') {
                openReceipt(product, godownNo, khamalNo);
              } else if (mode === 'shortage') {
                openDistribution(product, godownNo, khamalNo, 'shortage');
              } else {
                openDistribution(product, godownNo, khamalNo, 'existing');
              }
            }}
          />
        )}

        {/* VIEW 3: FULL CHANNEL, DO & SHORTAGE LEDGER */}
        {activeTab === 'ledger' && (
          <LedgerView
            transactions={store.transactions}
            pendingDos={store.pendingDos}
            distributedDos={store.distributedDos}
            gasData={store.gasData}
            gasBridgeStatus={store.gasBridgeStatus}
            initialSubTab={ledgerSubTab}
            isSyncingDos={store.isSyncingDos}
            onSyncExternalDos={() => void store.manualRefreshData()}
            onStartDoDistribution={(prod) => openDistribution(prod)}
            onMarkDoDistributed={store.markDoAsDistributed}
            onDeleteDeliveryOrder={store.deleteDeliveryOrder}
            onDeleteTransaction={store.deleteTransaction}
            onDeleteGasRecord={store.deleteGasRecord}
            onExportCsv={store.exportCsvReport}
          />
        )}

        {/* VIEW 4: FORTNIGHTLY STOCK VERIFICATION REPORT */}
        {activeTab === 'report' && (
          <FortnightlyReportView
            transactions={store.transactions}
            gasData={store.gasData}
            gasBridgeStatus={store.gasBridgeStatus}
            settings={store.fortnightlySettings}
            isSyncingDos={store.isSyncingDos}
            onSyncExternalDos={() => void store.manualRefreshData()}
            onOpenReportSettings={() => {
              setActiveTab('settings');
              window.setTimeout(() => {
                document
                  .getElementById('fortnightly-letter-settings')
                  ?.scrollIntoView({ behavior: 'smooth', block: 'start' });
              }, 80);
            }}
          />
        )}

        {/* VIEW 5: SETTINGS */}
        {activeTab === 'settings' && (
          <SettingsView
            channels={store.channels}
            deliveryOrders={store.deliveryOrders}
            externalSyncConfig={store.externalSyncConfig}
            isSyncingDos={store.isSyncingDos}
            gasData={store.gasData}
            gasBridgeStatus={store.gasBridgeStatus}
            gasBridgeMessage={store.gasBridgeMessage}
            onUpdateExternalSyncConfig={store.updateExternalSyncConfig}
            onSyncExternalDos={store.syncExternalDos}
            onSaveGasInstitution={store.saveGasInstitution}
            onSaveGasCategories={store.saveGasCategories}
            onAddGasFiscalYear={store.addGasFiscalYear}
            onSetActiveGasFiscalYear={store.setActiveGasFiscalYear}
            onDeleteGasFiscalYear={store.deleteGasFiscalYear}
            initialProduct={settingsPreset.product}
            initialMode={settingsPreset.mode}
            onAddChannel={store.addChannel}
            onRenameChannel={store.renameChannel}
            onRemoveChannel={store.removeChannel}
            onResetDefaultChannels={store.resetDefaultChannels}
            onAddDeliveryOrder={store.addDeliveryOrder}
            onDeleteDeliveryOrder={store.deleteDeliveryOrder}
            fortnightlySettings={store.fortnightlySettings}
            onUpdateFortnightlySettings={store.updateFortnightlySettings}
            onResetFortnightlySettings={store.resetFortnightlySettings}
            onExportBackup={store.exportBackupJson}
            onImportBackup={store.importBackupJson}
            onLoadSampleData={store.loadSampleData}
            onClearAllData={store.clearAllData}
            googleSheetsConfig={store.googleSheetsConfig}
            googleUser={store.googleUser}
            hasGoogleToken={store.hasGoogleToken}
            isGoogleSigningIn={store.isGoogleSigningIn}
            googleAuthError={store.googleAuthError}
            availableSpreadsheets={store.availableSpreadsheets}
            isLoadingSpreadsheets={store.isLoadingSpreadsheets}
            mainSheetTabs={store.mainSheetTabs}
            dataSourceMode={store.dataSourceMode}
            onGoogleSignIn={store.handleGoogleSignIn}
            onGoogleSignOut={store.handleGoogleSignOut}
            onRefreshSpreadsheets={store.refreshSpreadsheetsList}
            onSelectSpreadsheetsAndSync={store.selectSpreadsheetsAndSync}
            onUpdateGoogleSheetsConfig={store.updateGoogleSheetsConfig}
          />
        )}
      </main>

      {/* Mobile Fixed Bottom Navigation Bar */}
      <nav
        aria-label="প্রধান নেভিগেশন"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 pb-safe"
      >
        <div className="grid grid-cols-5 h-16 items-center">
          {(
            [
              { id: 'home', label: 'হোম', icon: Home },
              { id: 'stock', label: 'মজুদ', icon: Warehouse },
              { id: 'ledger', label: 'রেকর্ড', icon: ClipboardList },
              { id: 'report', label: 'প্রতিবেদন', icon: FileCheck2 },
              { id: 'settings', label: 'সেটিংস', icon: Settings },
            ] as Array<{ id: MainTab; label: string; icon: React.ComponentType<{ className?: string }> }>
          ).map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => {
                  if (tab.id === 'ledger') setLedgerSubTab('ledger');
                  setActiveTab(tab.id);
                }}
                className={`h-full flex flex-col items-center justify-center gap-1 transition-colors cursor-pointer ${
                  active ? 'text-[#0D6E4E]' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <Icon className={`h-5 w-5 ${active ? 'stroke-[2.4]' : 'stroke-[1.9]'}`} />
                <span className="text-[11px] font-bold tracking-tight">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Receipt Batch Entry Modal */}
      <BatchEntryModal
        isOpen={receiptModal.open}
        initialProduct={receiptModal.product}
        initialGodown={receiptModal.godown}
        initialKhamal={receiptModal.khamal}
        channels={store.channels}
        godownList={store.godownList}
        onClose={() => setReceiptModal((prev) => ({ ...prev, open: false }))}
        onSwitchToDistribution={(prod) => openDistribution(prod)}
        onSaveBatch={handleSaveBatch}
        onQuickAddChannel={store.addChannel}
        onOpenChannelSettings={handleOpenChannelSettings}
      />

      {/* DO Distribution, Dispatch & Khamal Shortage Modal */}
      <DistributionDoModal
        isOpen={distModal.open}
        initialProduct={distModal.product}
        initialGodown={distModal.godown}
        initialKhamal={distModal.khamal}
        initialModalMode={distModal.modalMode}
        pendingDos={store.pendingDos}
        distributedDos={store.distributedDos}
        khamalStocks={store.khamalStocks}
        godownList={store.godownList}
        channels={store.channels}
        gasBridgeStatus={store.gasBridgeStatus}
        isSyncingDos={store.isSyncingDos}
        onSyncExternalDos={() => void store.manualRefreshData()}
        onClose={() => setDistModal((prev) => ({ ...prev, open: false }))}
        onSwitchToReceipt={(prod) => openReceipt(prod)}
        onOpenChannelSettings={handleOpenChannelSettings}
        onExecuteDoDistribution={handleExecuteDoDistribution}
        onSubmitDispatch={handleSubmitDispatch}
        onSubmitEmptyBagIssue={handleSubmitEmptyBagIssue}
        onPreviewShortageCascade={store.buildShortageCascadePlan}
        onSubmitDiscrepancy={handleSubmitDiscrepancy}
      />

      <SheetWriteConfirmModal
        request={store.pendingSheetConfirm}
        onConfirm={() => store.resolveSheetConfirm(true)}
        onCancel={() => store.resolveSheetConfirm(false)}
      />

      <OfflineIndicator />
    </div>
  );
}
